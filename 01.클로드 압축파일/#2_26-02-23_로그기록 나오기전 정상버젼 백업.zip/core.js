// ============================================================
// KIVOSY Factory Next Gen — core.js
// CoreEngine  |  v2.0.0 - Universal Multi-Model Architecture
//
// Now supports: Gemini (native), OpenAI-compatible (DeepSeek, Groq, Moonshot),
//               Hugging Face Inference API, and custom endpoints
// ============================================================

'use strict';

// ─────────────────────────────────────────────────────────────
// § 1. SecurityCore (unchanged - keeping your existing logic)
// ─────────────────────────────────────────────────────────────

const SecurityCore = (() => {
  const CODE_THREATS = [
    [/\brm\s+-rf\b/i,                             'Shell deletion command'],
    [/\bexec\s*\(/i,                              'exec() call'],
    [/\beval\s*\(/i,                              'eval() call'],
    [/document\.cookie/i,                         'Cookie access'],
    [/localStorage\.getItem\s*\(\s*['"]kivosy_/i, 'KIVOSY key exfiltration attempt'],
    [/fetch\s*\(\s*`[^`]*`/i,                     'fetch() with template literal URL (unverifiable)'],
    [/XMLHttpRequest/i,                            'XHR (use fetch with whitelisted URLs)'],
    [/navigator\.sendBeacon/i,                     'sendBeacon exfiltration'],
    [/window\.open\s*\(\s*['"](?!#)/i,            'window.open to external URL'],
    [/<script[^>]+src\s*=\s*['"](?!https?:\/\/(cdn\.|fonts\.|cdnjs\.|unpkg\.|jsdelivr\.|code\.|stackpath\.))/i,
                                                   'External script from unapproved domain'],
    [/atob\s*\(/i,                                 'Base64 decode (potential obfuscation)'],
    [/btoa\s*\([\s\S]*?fetch/is,                  'Base64-encoded fetch (obfuscation pattern)'],
    [/document\.write\s*\(/i,                      'document.write() injection risk'],
  ];

  const INJECTION_THREATS = [
    /ignore\s+(all\s+)?previous\s+instructions/i,
    /disregard.{0,20}system/i,
    /you\s+are\s+now\s+/i,
    /act\s+as\s+(?:an?\s+)?(?:evil|unrestricted|jailbreak)/i,
    /새로운\s*역할/,
    /이전\s*지시.{0,10}무시/,
    /system\s*prompt\s*:/i,
    /\[SYSTEM\]/i,
    /override\s+(safety|guidelines|restrictions)/i,
  ];

  const ALLOWED_CDN_HOSTS = new Set([
    'cdn.jsdelivr.net',
    'unpkg.com',
    'cdnjs.cloudflare.com',
    'fonts.googleapis.com',
    'fonts.gstatic.com',
    'cdn.tailwindcss.com',
    'code.jquery.com',
    'stackpath.bootstrapcdn.com',
    'cdn.tailwindcss.com',
  ]);

  const MAX_SIZE_KB = 500;

  return {
    validateCode(code) {
      const issues = [];
      for (const [pattern, reason] of CODE_THREATS) {
        if (pattern.test(code)) {
          // 한글 '위험 패턴' 대신 영어로 변경
          issues.push(`Security Pattern Detected [${reason}]`);
        }
      }
      const sizeKB = parseFloat((new Blob([code]).size / 1024).toFixed(2));
      if (sizeKB > MAX_SIZE_KB) {
        // '파일 크기 초과' 대신 영어로 변경
        issues.push(`Resource Limit Exceeded: ${sizeKB}KB (Max: ${MAX_SIZE_KB}KB)`);
      }
      return { safe: issues.length === 0, issues, sizeKB };
    },

    detectPromptInjection(input) {
      if (typeof input !== 'string') return false;
      return INJECTION_THREATS.some(p => p.test(input));
    },

    isCdnAllowed(url) {
      try {
        const host = new URL(url).hostname;
        return ALLOWED_CDN_HOSTS.has(host);
      } catch {
        return false;
      }
    },
  };
})();

// ─────────────────────────────────────────────────────────────
// § 2. PromptBuilder (unchanged - keeping your existing logic)
// ─────────────────────────────────────────────────────────────

/**
 * @typedef {Object} ChatTurn
 * @property {'user'|'assistant'} role
 * @property {string}             content
 */

const PromptBuilder = (() => {
  const SYSTEM_INSTRUCTION = `You are an expert senior frontend developer specializing in self-contained, single-file web applications.

OUTPUT RULES (non-negotiable):
1. Output ONLY raw HTML. No markdown fences, no explanation, no surrounding text.
2. The file must be 100% self-contained: all CSS and JS embedded inside the HTML.
3. External resources: ONLY from these CDNs: cdn.jsdelivr.net, unpkg.com, cdnjs.cloudflare.com, fonts.googleapis.com, cdn.tailwindcss.com, code.jquery.com, stackpath.bootstrapcdn.com.
4. FORBIDDEN: eval(), exec(), document.cookie, XMLHttpRequest, window.open() to external URLs, fetch() to unknown domains, document.write().
5. Must be fully functional — not a wireframe or mockup. All buttons and interactions must work.
6. Responsive design (mobile + desktop).
7. Korean UI labels unless the user explicitly requests another language.
8. Use localStorage for any data persistence within the app.
9. Clean, modern aesthetic. Prefer a soft color palette with clear typography.`;

  return {
    forGeneration(userPrompt, history = []) {
      const userMessage = `Build this web app: ${userPrompt.trim()}`;
      return {
        system: SYSTEM_INSTRUCTION,
        messages: [...history, { role: 'user', content: userMessage }],
      };
    },

    forModification(currentHtml, instruction, history = []) {
      const htmlSnippet = currentHtml.length > 60_000
        ? currentHtml.slice(0, 60_000) + '\n<!-- [truncated for context limit] -->'
        : currentHtml;

      const userMessage =
        `Modify the following web app according to my request. ` +
        `Return the complete, updated HTML file.\n\n` +
        `MODIFICATION REQUEST: ${instruction.trim()}\n\n` +
        `CURRENT HTML:\n${htmlSnippet}`;

      return {
        system: SYSTEM_INSTRUCTION,
        messages: [...history, { role: 'user', content: userMessage }],
      };
    },

    getSystemInstruction() { return SYSTEM_INSTRUCTION; },
  };
})();

// ─────────────────────────────────────────────────────────────
// § 3. Universal Multi-Model Adapters
//      Supporting: Gemini Native, OpenAI-compatible (DeepSeek, Groq, Moonshot),
//                  Hugging Face Inference API
// ─────────────────────────────────────────────────────────────

/**
 * @typedef {Object} ModelConfig
 * @property {string} provider - 'gemini', 'openai', 'huggingface'
 * @property {string} modelId - Model identifier
 * @property {string} apiKey - API key
 * @property {string} [endpoint] - Optional custom endpoint
 * @property {number} [priority=1] - Priority in fallback chain (lower = higher priority)
 */

/**
 * Base adapter interface that all specific adapters implement
 */
class BaseAdapter {
  constructor(config) {
    this.config = config;
  }

  async call(systemInstruction, messages) {
    throw new Error('Adapter must implement call()');
  }

  getModelUsed() {
    return this.config.modelId;
  }
}

/**
 * Gemini Native Adapter (Google's official API)
 */
class GeminiAdapter extends BaseAdapter {
  async call(systemInstruction, messages) {
    // 🎯 1. 레퍼런스와 100% 동일한 설정
    const apiKey = this.config.apiKey;
    const model = 'gemini-2.5-flash'; // 💡 2.5가 아직 불안정할 수 있으니 검증된 1.5나 2.0-flash 사용
    
    // 🎯 2. 레퍼런스와 동일한 v1 주소
    const url = `https://generativelanguage.googleapis.com/v1/models/${model}:generateContent?key=${apiKey}`;

    // 🎯 3. 레퍼런스와 동일한 심플한 payload 구조
    // (messages 전체를 합쳐서 하나의 text로 보냅니다 - 레퍼런스 방식)
    const combinedPrompt = `${systemInstruction}\n\n${messages.map(m => m.content).join('\n')}`;

    const payload = {
      contents: [{
        parts: [{ text: combinedPrompt }]
      }],
      generationConfig: {
        temperature: 0.2, // 레퍼런스 값
        maxOutputTokens: 8192
      }
    };

    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      throw new Error(error.error?.message || `HTTP ${response.status}`);
    }

    const data = await response.json();
    
    // 데이터 구조 안전하게 파싱 (레퍼런스 방식)
    try {
      return data.candidates[0].content.parts[0].text;
    } catch (e) {
      throw new Error("Gemini response parsing error");
    }
  }
}

/**
 * OpenAI-compatible Adapter (DeepSeek, Groq, Moonshot, etc.)
 * Uses standard OpenAI chat completions format
 */
class OpenAICompatibleAdapter extends BaseAdapter {
  async call(systemInstruction, messages) {
    // ✅ [수정] 공급자에 따라 올바른 엔드포인트를 할당합니다.
    let endpoint = this.config.endpoint;
    
    if (!endpoint) {
      if (this.config.provider === 'groq') {
        endpoint = 'https://api.groq.com/openai/v1/chat/completions';
      } else {
        // 기본값은 OpenAI로 유지
        endpoint = 'https://api.openai.com/v1/chat/completions';
      }
    }

    const openAiMessages = [
      { role: 'system', content: systemInstruction },
      ...messages.map(m => ({ role: m.role, content: m.content })),
    ];

    // ... (나머지 payload 및 fetch 로직은 동일)
    const payload = {
      model: this.config.modelId,
      messages: openAiMessages,
      temperature: 0.2,
      max_tokens: 32768,
    };

    const response = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.config.apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(`${this.config.provider} API ${response.status}: ${err?.error?.message ?? response.statusText}`);
    }

    const data = await response.json();
    const text = data?.choices?.[0]?.message?.content;
    if (!text) throw new Error(`${this.config.provider} returned an empty response.`);
    return text;
  }
}

/**
 * 🚀 Hugging Face Adapter (Next-Gen Router Version)
 * Optimized for English websites and stable API calls.
 */
class HuggingFaceAdapter extends BaseAdapter {
  async call(systemInstruction, messages) {
    // 🎯 Using the ultra-stable Router endpoint
    const url = 'https://router.huggingface.co/v1/chat/completions';
    
    const payload = {
      model: this.config.modelId, // e.g., "Qwen/Qwen2.5-Coder-32B-Instruct"
      messages: [
        { role: 'system', content: systemInstruction },
        ...messages
      ],
      temperature: 0.7,
      max_tokens: 2048,
    };

    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.config.apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(`HF API Error: ${err.error?.message || response.statusText}`);
    }

    const data = await response.json();
    
    // 🎯 Clean and reliable response extraction
    if (data.choices && data.choices[0] && data.choices[0].message) {
      return data.choices[0].message.content;
    }
    
    throw new Error('Invalid response format from Hugging Face.');
  }
}

/**
 * Factory function to create appropriate adapter based on provider
 */
function createAdapter(providerConfig) {
  const { provider } = providerConfig;
  
  switch (provider) {
    case 'gemini':
      return new GeminiAdapter(providerConfig);
    case 'openai':
    case 'deepseek':
    case 'groq':
    case 'moonshot':
      return new OpenAICompatibleAdapter(providerConfig);
    case 'huggingface':
    case 'hf':
      return new HuggingFaceAdapter(providerConfig);
    default:
      throw new Error(`Unsupported provider: ${provider}`);
  }
}

// ─────────────────────────────────────────────────────────────
// § 4. CodeProcessor (unchanged - keeping your existing logic)
// ─────────────────────────────────────────────────────────────

const CodeProcessor = (() => {
  const BRAND = {
    ADSENSE_CLIENT:  'ca-pub-5981094525589755',
    ADSENSE_SLOT:    'XXXXXXXXXX',
    GA_MEASUREMENT:  'G-Q7K55RZKNW',
    SITE_URL:        'https://lab.kivosy.com',
    SITE_LABEL:      'KIVOSY Labs',
  };

  function buildAdSenseBlock() {
    return `
  <!-- KIVOSY AdSense -->
  <div style="text-align:center;margin:20px 0;">
    <ins class="adsbygoogle"
         style="display:block"
         data-ad-client="${BRAND.ADSENSE_CLIENT}"
         data-ad-slot="${BRAND.ADSENSE_SLOT}"
         data-ad-format="auto"
         data-full-width-responsive="true"></ins>
    <script>(adsbygoogle = window.adsbygoogle || []).push({});<\/script>
  </div>`;
  }

  function buildFooter(prompt, uuid) {
    const safePrompt = prompt
      .replace(/&/g, '&amp;')
      .replace(/"/g, '&quot;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .slice(0, 150);

    return `
  <footer style="margin-top:40px;padding:16px 24px;text-align:center;font-size:12px;color:#94a3b8;border-top:1px solid #e2e8f0;background:#f8fafc;">
    ⚡ Made with&nbsp;<a href="${BRAND.SITE_URL}" target="_blank" rel="noopener"
       style="color:#6366f1;text-decoration:none;font-weight:600;">${BRAND.SITE_LABEL}</a>
    &nbsp;·&nbsp; App ID:&nbsp;<code style="font-size:10px;color:#64748b;">${uuid.slice(0, 8)}</code>
    &nbsp;·&nbsp; <span title="${safePrompt}" style="cursor:help;">AI Generated ✨</span>
  </footer>`;
  }

  function buildHeadInjection() {
    return `
  <!-- KIVOSY Analytics & AdSense -->
  <script async src="https://www.googletagmanager.com/gtag/js?id=${BRAND.GA_MEASUREMENT}"><\/script>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', '${BRAND.GA_MEASUREMENT}');
  <\/script>
  <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${BRAND.ADSENSE_CLIENT}" crossorigin="anonymous"><\/script>`;
  }

  return {
    stripFences(raw) {
      return raw
        .replace(/^```html\s*/i, '')
        .replace(/^```\s*/,      '')
        .replace(/\s*```$/,      '')
        .trim();
    },

    injectBrandElements(html, prompt, uuid) {
      let out = html;

      const headBlock = buildHeadInjection();
      if (out.includes('</head>')) {
        out = out.replace('</head>', `${headBlock}\n</head>`);
      } else if (out.includes('<head>')) {
        out = out.replace('<head>', `<head>${headBlock}`);
      } else {
        out = headBlock + '\n' + out;
      }

      const bodyBlock = buildAdSenseBlock() + buildFooter(prompt, uuid);
      if (out.includes('</body>')) {
        out = out.replace('</body>', `${bodyBlock}\n</body>`);
      } else {
        out += bodyBlock;
      }

      return out;
    },

    process(raw, prompt, uuid) {
      const cleaned    = this.stripFences(raw);
      const validation = SecurityCore.validateCode(cleaned);

      if (!validation.safe) {
        // 🛡️ 거대 기업 스타일의 정중하고 전문적인 영문 보안 메시지 구성
        const errorHeader = "🛡️ Security Shield: Protection Active";
        const errorSub    = "We've identified potentially unsafe patterns in the generated code to ensure your system's safety.";
        const issueList   = validation.issues.map(i => `  • ${i}`).join('\n');
        const proTip      = "💡 Pro Tip: If this was unexpected, try asking the AI to 'Avoid using cookies or sensitive APIs' and generate again.";

        throw new Error(
          `${errorHeader}\n\n${errorSub}\n\nDetected Issues:\n${issueList}\n\n${proTip}`
        );
      }

      const html = this.injectBrandElements(cleaned, prompt, uuid);
      return { html, validation };
    },
  };
})();

// ─────────────────────────────────────────────────────────────
// § 5. CoreEngine - Universal Multi-Model Orchestrator
// ─────────────────────────────────────────────────────────────

/**
 * @typedef {Object} GenerationConfig
 * @property {Array<ModelConfig>} models - Array of model configurations in priority order
 * @property {Function} [onProgress] - Callback: (message: string) => void
 */

/**
 * @typedef {Object} GenerationResult
 * @property {string}       uuid       - Unique ID for this app
 * @property {string}       html       - Final injected HTML
 * @property {import('./storage.js').AppMetadata} metadata - Persisted metadata
 * @property {Object}       stats      - Timing and model info
 * @property {string}       stats.modelUsed
 * @property {number}       stats.durationMs
 * @property {number}       stats.sizeKB
 * @property {number}       stats.tokensEstimate
 */

class CoreEngine {
  constructor(storage) {
    if (!storage) throw new Error('[CoreEngine] storage dependency is required.');
    this.#storage = storage;
  }

  /** @type {StorageEngine} */
  #storage;

  /**
   * Generates a brand-new web app from a user prompt.
   * @param {GenerationConfig} config
   * @param {string}           userPrompt
   * @param {ChatTurn[]}       [history=[]]
   * @returns {Promise<GenerationResult>}
   */
  async generateApp(config, userPrompt, history = []) {
    const progress = config.onProgress ?? (() => {});
    const t0 = Date.now();

    // 1. Security: prompt injection check
    if (SecurityCore.detectPromptInjection(userPrompt)) {
      throw new Error('⚠️ Security Alert: Potential prompt injection detected. Please refine your input.');
    }

    // 2. Quota: check + consume
    progress('📊 Checking system quota...');
    await this.#storage.assertAndConsumeQuota();

    // 3. Build prompt
    const { system, messages } = PromptBuilder.forGeneration(userPrompt, history);

    // 4. Try models in priority order with fallback
    progress('🤖 Generating code via AI Ensemble...');
    const { rawCode, modelUsed, providerUsed } = await this.#callWithFallback(config, system, messages, progress);

    // 5+6. Clean, validate, inject
    progress('🔒 Verifying security & injecting KIVOSY elements...');
    const uuid = this.#generateUUID();
    const { html, validation } = CodeProcessor.process(rawCode, userPrompt, uuid);

    // 7. Persist
    progress('💾 Finalizing and saving your app...');
    const { meta } = await this.#storage.apps.save(html, userPrompt, {
      uuid,
      modelUsed: `${providerUsed}:${modelUsed}`,
      tags: this.#autoDetectTags(userPrompt),
    });
    
    // 8. Update session
    this.#storage.session.setActiveApp({
      uuid,
      html,
      isDirty: false,
      chatHistory: [],
    });

    // 🎯 [추가] 에디터 연동을 위한 전역 변수 설정
    window.lastGeneratedCode = html;

    const durationMs = Date.now() - t0;
    const tokensEstimate = Math.round(new Blob([rawCode]).size / 4);

    progress(`✅ Success! App ID: ${uuid.slice(0, 8)} · ${(durationMs / 1000).toFixed(1)}s`);

    return {
      uuid,
      html,
      metadata: meta,
      stats: {
        modelUsed: `${providerUsed}:${modelUsed}`,
        durationMs,
        sizeKB: validation.sizeKB,
        tokensEstimate,
      },
    };
  }

  /**
   * Modifies an existing app via a chat instruction.
   * @param {GenerationConfig} config
   * @param {string}           currentHtml
   * @param {string}           instruction
   * @param {string}           uuid
   * @param {ChatTurn[]}       [history=[]]
   * @returns {Promise<GenerationResult>}
   */
  async modifyApp(config, currentHtml, instruction, uuid, history = []) {
    const progress = config.onProgress ?? (() => {});
    const t0 = Date.now();

    if (SecurityCore.detectPromptInjection(instruction)) {
      throw new Error('⚠️ Security Alert: Potential prompt injection detected. Please refine your input.');
    }

    progress('📊 Checking system quota...');
    await this.#storage.assertAndConsumeQuota();

    const { system, messages } = PromptBuilder.forModification(currentHtml, instruction, history);

    progress('🔧 AI is refactoring your app...');
    const { rawCode, modelUsed, providerUsed } = await this.#callWithFallback(config, system, messages, progress);

    progress('🔒 Verifying security standards...');
    const originalMeta = await this.#storage.apps.getMeta(uuid);
    const originalPrompt = originalMeta?.prompt ?? instruction;

    const { html, validation } = CodeProcessor.process(rawCode, originalPrompt, uuid);

    progress('💾 Applying and saving changes...');
    const { meta } = await this.#storage.apps.save(html, originalPrompt, {
      uuid,
      modelUsed: `${providerUsed}:${modelUsed}`,
    });

    this.#storage.session.patchActiveHtml(html);
    this.#storage.session.appendChatMessage(instruction);

    // 🎯 [추가] 수정된 코드를 에디터 전역 변수에 동기화
    window.lastGeneratedCode = html;
    
    const durationMs = Date.now() - t0;
    const tokensEstimate = Math.round(new Blob([rawCode]).size / 4);

    progress(`✅ Update Successful! · ${(durationMs / 1000).toFixed(1)}s`);

    return {
      uuid,
      html,
      metadata: meta,
      stats: { modelUsed: `${providerUsed}:${modelUsed}`, durationMs, sizeKB: validation.sizeKB, tokensEstimate },
    };
  }

  /**
   * Opens a saved app in a new browser tab.
   * @param {string} uuid
   * @returns {Promise<void>}
   */
  async openApp(uuid) {
    const html = await this.#storage.apps.getHtml(uuid);
    if (!html) {
      throw new Error(`Application Not Found: The requested ID does not exist in the database. (ID: ${uuid.slice(0, 8)})`);
    }
    const blob = new Blob([html], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    window.open(url, '_blank', 'noopener');
    setTimeout(() => URL.revokeObjectURL(url), 30_000);
  }

  /**
   * Tests a model configuration without saving/quota consumption
   * @param {ModelConfig} modelConfig
   * @param {string} systemInstruction
   * @param {Array<ChatTurn>} messages
   * @returns {Promise<string>}
   */
  async testModel(modelConfig, systemInstruction, messages) {
    const adapter = createAdapter(modelConfig);
    return await adapter.call(systemInstruction, messages);
  }

  // ── Private Helpers ────────────────────────────────────────

  /**
   * Tries each model configuration in priority order until one succeeds
   */
  async #callWithFallback(config, system, messages, progress) {
    if (!config.models || config.models.length === 0) {
      throw new Error('No models configured. Please add at least one model configuration.');
    }

    // Sort models by priority (lower number = higher priority)
    const sortedModels = [...config.models].sort((a, b) => 
      (a.priority || 99) - (b.priority || 99)
    );

    const errors = [];

    for (const modelConfig of sortedModels) {
      const provider = modelConfig.provider;
      const modelId = modelConfig.modelId;

      if (!modelConfig.apiKey) {
        errors.push(`${provider}:${modelId} - API key missing`);
        continue;
      }

      progress(`✨ Initializing generation with ${provider} (${modelId})...`);

      try {
        const adapter = createAdapter(modelConfig);
        const rawCode = await adapter.call(system, messages);
        return { 
          rawCode, 
          modelUsed: modelId,
          providerUsed: provider
        };
      } catch (err) {
        console.warn(`[CoreEngine] ${provider}:${modelId} failed:`, err.message);
        errors.push(`${provider}:${modelId} - ${err.message}`);
      }
    }

    throw new Error(
        `❌ All AI model attempts failed:\n${errors.map(e => '  • ' + e).join('\n')}\n\n` +
        `Please verify your API keys and model configurations in the settings.`
    );
  }

  #generateUUID() {
    if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
      return crypto.randomUUID();
    }
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
      const r = (Math.random() * 16) | 0;
      return (c === 'x' ? r : (r & 0x3) | 0x8).toString(16);
    });
  }

  #autoDetectTags(prompt) {
    const p = prompt.toLowerCase();
    const tags = [];
    const map = [
      ['todo',          ['할일', 'todo', 'task']],
      ['calculator',    ['계산기', 'calculator']],
      ['timer',         ['타이머', 'timer', '포모도로', 'pomodoro']],
      ['weather',       ['날씨', 'weather']],
      ['note',          ['메모', 'note', '노트']],
      ['chat',          ['채팅', 'chat']],
      ['game',          ['게임', 'game', 'quiz', '퀴즈']],
      ['finance',       ['계산', '환율', '환전', 'currency', 'exchange', '금융']],
      ['health',        ['bmi', '칼로리', 'calorie', '식단', 'diet', 'health']],
      ['productivity',  ['일정', 'schedule', '플래너', 'planner']],
    ];
    for (const [tag, keywords] of map) {
      if (keywords.some(k => p.includes(k))) tags.push(tag);
    }
    return tags;
  }
}

// ─────────────────────────────────────────────────────────────
// § 6. Bootstrap & Public API
// ─────────────────────────────────────────────────────────────

if (typeof window.KivosyStorage === 'undefined') {
  throw new Error(
    '[core.js] window.KivosyStorage not found. ' +
    'Ensure storage.js is loaded BEFORE core.js in your HTML.'
  );
}

const _engine = new CoreEngine(window.KivosyStorage);

/**
 * Public API surface
 */
window.KivosyCore = Object.freeze({
  generateApp: _engine.generateApp.bind(_engine),
  modifyApp: _engine.modifyApp.bind(_engine),
  openApp: _engine.openApp.bind(_engine),
  testModel: _engine.testModel.bind(_engine),
  
  // Expose utilities
  security: SecurityCore,
  processor: CodeProcessor,
  prompts: PromptBuilder,
  
  // Export adapter classes for custom configuration
  adapters: {
    GeminiAdapter,
    OpenAICompatibleAdapter,
    HuggingFaceAdapter,
    createAdapter
  }
});