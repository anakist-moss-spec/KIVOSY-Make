// ============================================================
// KIVOSY Factory Next Gen — ui.js
// UIEngine  |  v1.0.0
//
// The Command Center: every pixel the user sees, every click
// they make, every toast they read originates here.
//
// Responsibilities:
//   1. ToastSystem      — Beautiful notifications with type theming
//   2. ApiKeyManager    — Secure key I/O (load, save, mask)
//   3. QuotaDisplay     — Live quota bar + header counter
//   4. FactoryController — Main generation flow (prompt → result)
//   5. ChatController   — Inline app-modification chat
//   6. PreviewPanel     — Split-view iframe management + fullscreen
//   7. HistoryPanel     — App history list on the factory page
//   8. GalleryController — gallery.html: render, search, CRUD
//   9. UIEngine (boot)  — Wires everything together; single DOMContentLoaded
//
// Dependencies (must be loaded before this file):
//   window.KivosyStorage  (storage.js)
//   window.KivosyCore     (core.js)
//
// NO global variables. All state lives in KivosyStorage.session
// or as private class fields.
// ============================================================

'use strict';

// ─────────────────────────────────────────────────────────────
// Guard: ensure peer dependencies are present
// ─────────────────────────────────────────────────────────────
if (typeof window.KivosyStorage === 'undefined') {
  throw new Error('[ui.js] window.KivosyStorage not found. Load storage.js first.');
}
if (typeof window.KivosyCore === 'undefined') {
  throw new Error('[ui.js] window.KivosyCore not found. Load core.js first.');
}

const { KivosyStorage: Storage, KivosyCore: Core } = window;

// ─────────────────────────────────────────────────────────────
// § 0. Storage Extension (이 수석의 '중복 선언' 완벽 해결 버전)
// ─────────────────────────────────────────────────────────────

// Storage.usage가 없는 경우에만 확장 기능을 추가합니다.
if (Storage && !Storage.usage) {
  Storage.usage = {
    async recordCall(modelName) {
      const today = new Date().toISOString().slice(0, 10);
      const key = `kivosy_usage_${today}`;
      let stats = JSON.parse(localStorage.getItem(key) || '{}');
      
      const lower = (modelName || 'other').toLowerCase();
      const cleanName = lower.includes('gemini') ? 'gemini' : 
                        lower.includes('groq') ? 'groq' : 
                        lower.includes('hugging') ? 'huggingface' : 'other';
      
      stats[cleanName] = (stats[cleanName] || 0) + 1;
      localStorage.setItem(key, JSON.stringify(stats));
    },

    async getDailyStats() {
      const today = new Date().toISOString().slice(0, 10);
      const key = `kivosy_usage_${today}`;
      return JSON.parse(localStorage.getItem(key) || '{}');
    },

    async getSummary() {
      const stats = await this.getDailyStats();
      const used = Object.values(stats).reduce((a, b) => a + b, 0);
      return { used };
    }
  };
}

// ─────────────────────────────────────────────────────────────
// § 1. ToastSystem
//      A self-managing notification queue. Renders rich toasts
//      with contextual icons and colours; auto-dismisses.
// ─────────────────────────────────────────────────────────────

const ToastSystem = (() => {
  /** @type {HTMLElement|null} */
  let _container = null;
  let _queue = [];
  let _processing = false;

 // Theme map: type → { bg, icon, label }
  // 영어 웹사이트 지침에 따른 영문 레이블 업데이트
  const THEMES = {
    success:  { bg: '#10b981', icon: '✅', label: 'Success' },
    error:    { bg: '#ef4444', icon: '🚫', label: 'Error' },
    warning:  { bg: '#f59e0b', icon: '⚠️', label: 'Warning' },
    info:     { bg: '#6366f1', icon: '💡', label: 'Notice' },
    security: { bg: '#7c3aed', icon: '🔒', label: 'Blocked' },
    copy:     { bg: '#0d6efd', icon: '📋', label: 'Copied' },
    save:     { bg: '#059669', icon: '💾', label: 'Saved' },
    publish:  { bg: '#ec4899', icon: '🚀', label: 'Ready to Publish' },
  };
  function _getContainer() {
    if (!_container) {
      _container = document.createElement('div');
      _container.id = 'kivosy-toast-root';
      Object.assign(_container.style, {
        position: 'fixed',
        bottom: '24px',
        left: '50%',
        transform: 'translateX(-50%)',
        zIndex: '99999',
        display: 'flex',
        flexDirection: 'column-reverse',
        alignItems: 'center',
        gap: '10px',
        pointerEvents: 'none',
      });
      document.body.appendChild(_container);
    }
    return _container;
  }

  /**
   * Shows a toast notification.
   * @param {string} message
   * @param {'success'|'error'|'warning'|'info'|'security'|'copy'|'save'|'publish'} [type='info']
   * @param {number} [durationMs=3000]
   */
  function show(message, type = 'info', durationMs = 3000) {
    const theme = THEMES[type] || THEMES.info;
    const container = _getContainer();

    const toast = document.createElement('div');
    toast.style.cssText = `
      background: ${theme.bg};
      color: white;
      padding: 12px 22px;
      border-radius: 40px;
      font-size: 14px;
      font-weight: 500;
      pointer-events: all;
      box-shadow: 0 20px 30px -10px ${theme.bg}80;
      display: flex;
      align-items: center;
      gap: 8px;
      white-space: nowrap;
      max-width: min(90vw, 480px);
      overflow: hidden;
      text-overflow: ellipsis;
      animation: kivosy-toast-in 0.3s cubic-bezier(0.175,0.885,0.32,1.275) forwards;
      cursor: pointer;
    `;
    toast.innerHTML = `<span>${theme.icon}</span><span>${message}</span>`;

    // Inject keyframe once
    if (!document.getElementById('kivosy-toast-style')) {
      const style = document.createElement('style');
      style.id = 'kivosy-toast-style';
      style.textContent = `
        @keyframes kivosy-toast-in {
          from { opacity:0; transform:translateY(16px) scale(0.95); }
          to   { opacity:1; transform:translateY(0)    scale(1);    }
        }
        @keyframes kivosy-toast-out {
          from { opacity:1; transform:translateY(0)    scale(1);    }
          to   { opacity:0; transform:translateY(12px) scale(0.95); }
        }
      `;
      document.head.appendChild(style);
    }

    // Click to dismiss early
    toast.addEventListener('click', () => _dismiss(toast));

    container.appendChild(toast);

    setTimeout(() => _dismiss(toast), durationMs);
  }

  function _dismiss(toast) {
    if (!toast.parentNode) return;
    toast.style.animation = 'kivosy-toast-out 0.25s ease forwards';
    setTimeout(() => toast.remove(), 250);
  }

  return { show };
})();


// ─────────────────────────────────────────────────────────────
// § 2. ApiKeyManager
//      Loads/saves Gemini and Groq API keys from localStorage.
//      Supports both the legacy keys and the unified config blob
//      written by lab.kivosy.com, so existing users aren't broken.
// § 2. ApiKeyManager (Gemini, Groq, HF 전용)
// ─────────────────────────────────────────────────────────────

const ApiKeyManager = {
  load() {
    try {
      const raw = localStorage.getItem('kivosy_keys');
      const cfg = raw ? JSON.parse(raw) : {};
      
      return {
        // cfg에 저장된 이름이 gemini인지 geminiKey인지 확인해서 둘 다 대응!
        gemini: cfg.gemini || cfg.geminiKey || '',
        groq:   cfg.groq   || cfg.groqKey   || '',
        hf:     cfg.hf     || cfg.hfKey     || '',
        geminiModel: document.getElementById('gemini-model-select')?.value || 'gemini-2.0-flash',
        groqModel:   document.getElementById('groq-model-select')?.value   || 'llama-3.3-70b-versatile',
        hfModel:     document.getElementById('hf-model-select')?.value     || 'Qwen/Qwen2.5-Coder-32B-Instruct'
      };
    } catch (e) {
      return { gemini:'', groq:'', hf:'', geminiModel:'gemini-2.0-flash' };
    }
  },

  /** 셋 중 하나라도 키가 있는지 확인 */
  hasAnyKey() {
    const keys = this.load();
    return Boolean(keys.gemini || keys.groq || keys.hf);
  },

  saveFromModal() {
    const gInput = document.getElementById('gemini-key');
    const rInput = document.getElementById('groq-key');
    const hInput = document.getElementById('hf-key');

    const newGemini = gInput?.value?.trim() || '';
    const newGroq   = rInput?.value?.trim() || '';
    const newHf     = hInput?.value?.trim() || '';

    // 🎯 [핵심] 기존 키를 불러옵니다.
    const oldKeys = this.load();
    const keyData = { ...oldKeys };

    // 🎯 [핵심] 만약 입력창이 비어있거나 '***' 별표라면 기존 키를 유지하고, 
    // 새로운 값이 들어왔을 때만 교체합니다! (이게 없어서 별표가 저장됐던 것)
    if (newGemini && !newGemini.includes('*')) keyData.gemini = newGemini;
    if (newGroq   && !newGroq.includes('*'))   keyData.groq   = newGroq;
    if (newHf     && !newHf.includes('*'))     keyData.hf     = newHf;

    localStorage.setItem('kivosy_keys', JSON.stringify(keyData));

    this.closeModal();
    ToastSystem.show('Keys updated successfully!', 'save');
  },

  showModal() {
    const modal = document.getElementById('api-key-modal');
    if (!modal) return;
    const keys = this.load();
    
    const gInput = document.getElementById('gemini-key');
    const rInput = document.getElementById('groq-key');
    const hInput = document.getElementById('hf-key');
    
    if (gInput && keys.gemini) gInput.placeholder = '••••' + keys.gemini.slice(-4);
    if (rInput && keys.groq)   rInput.placeholder = '••••' + keys.groq.slice(-4);
    if (hInput && keys.hf)     hInput.placeholder = '••••' + keys.hf.slice(-4);
    
    modal.style.display = 'block';
  },

  closeModal() {
    const modal = document.getElementById('api-key-modal');
    if (modal) modal.style.display = 'none';
  }
};


// ─────────────────────────────────────────────────────────────
// § 3. QuotaDisplay
//      Keeps the quota bar, header counter, and factory header
//      counter in sync after every generation or page load.
// ─────────────────────────────────────────────────────────────

window.QuotaDisplay = {
    async refresh() {
        try {
            // 1. 데이터 가져오기 (Storage 객체가 core.js 등에 정의되어 있어야 함)
            if (typeof Storage === 'undefined' || !Storage.usage) return;
            
            const stats = await Storage.usage.getDailyStats();
            const total = Object.values(stats).reduce((a, b) => a + b, 0);

            // 2. 상단 배지 업데이트 (index, gallery 공통)
            const dailyUsageEl = document.getElementById('daily-usage');
            if (dailyUsageEl) {
                dailyUsageEl.textContent = `Today: ${total} Calls`;
            }

            // 3. 인덱스 전용: 중앙 쿼터 바 업데이트
            const quotaUsedEl = document.getElementById('quota-used');
            if (quotaUsedEl) quotaUsedEl.textContent = total;

            const quotaFillEl = document.getElementById('quota-fill');
            if (quotaFillEl) {
                const percentage = Math.min((total / 10) * 100, 100); 
                quotaFillEl.style.width = `${percentage}%`;
            }

            // 4. 대시보드 새로고침
            if (window.UIEngine && UIEngine.refreshUsageDashboard) {
                await UIEngine.refreshUsageDashboard();
            }
            
            console.log("📊 Quota Refreshed:", total);
        } catch (e) {
            console.warn("Quota Refresh Skip:", e.message);
        }
    }
};

// 페이지 로드 시 자동으로 숫자 새로고침 실행
document.addEventListener('DOMContentLoaded', () => {
    // 약간의 지연을 주어 다른 데이터(Storage 등)가 로드될 시간을 줍니다.
    setTimeout(() => {
        window.QuotaDisplay.refresh();
    }, 100);
});


// ─────────────────────────────────────────────────────────────
// § 4. ProgressPanel
//      Manages the live step-by-step progress display during
//      generation. Includes a running elapsed-time ticker.
// ─────────────────────────────────────────────────────────────

const ProgressPanel = (() => {
  let _timerHandle = null;
  let _startTime   = 0;
  let _lastMsg     = '';

  function _getContainer() { return document.getElementById('progress-steps'); }

  function show() {
    const el = document.getElementById('factory-progress');
    if (el) el.style.display = 'block';
    const container = _getContainer();
    if (container) container.innerHTML = '';
    _startTime = Date.now();
    _lastMsg   = '';

    // Tick every second
    _timerHandle = setInterval(() => {
      const sec  = Math.floor((Date.now() - _startTime) / 1000);
      const min  = Math.floor(sec / 60);
      const time = min > 0 ? `${min}m ${sec % 60}s` : `${sec}s`;
      _updateLast(`⏱️ ${_lastMsg}... ${time} elapsed`);
    }, 1000);
  }

  function hide() {
    if (_timerHandle) { clearInterval(_timerHandle); _timerHandle = null; }
    const el = document.getElementById('factory-progress');
    if (el) el.style.display = 'none';
  }

  function addStep(msg, done = false) {
    _lastMsg = msg;
    const container = _getContainer();
    if (!container) return;
    const el = document.createElement('div');
    el.className = 'progress-step' + (done ? ' done' : '');
    el.textContent = msg;
    container.appendChild(el);
    container.scrollTop = container.scrollHeight;
  }

  function _updateLast(msg) {
    const container = _getContainer();
    if (!container) return;
    const last = container.lastElementChild;
    if (last?.classList.contains('progress-step')) {
      last.textContent = msg;
    } else {
      addStep(msg);
    }
    container.scrollTop = container.scrollHeight;
  }

  return { show, hide, addStep };
})();


// ─────────────────────────────────────────────────────────────
// § 5. PreviewPanel
//      Owns the split-view iframe. Handles rendering, refresh,
//      and fullscreen toggle. Also exposes a thumbnail scraper
//      for the gallery card pseudo-preview.
// ─────────────────────────────────────────────────────────────

const PreviewPanel = {
  /** @type {string|null} */
  _currentBlobUrl: null,

  /**
   * Renders HTML into the result iframe.
   * Revokes the previous Blob URL to prevent memory leaks.
   * @param {string} html
   */
  render(html) {
    const iframe = document.getElementById('result-preview');
    if (!iframe) return;
    if (this._currentBlobUrl) {
      URL.revokeObjectURL(this._currentBlobUrl);
    }
    const blob = new Blob([html], { type: 'text/html' });
    this._currentBlobUrl = URL.createObjectURL(blob);
    iframe.src = this._currentBlobUrl;
  },

  refresh() {
    const active = Storage.session.activeApp;
    if (active?.html) this.render(active.html);
  },

  /**
   * Toggles fullscreen mode on the split layout.
   * Uses a CSS class defined in style.css.
   */
  toggleFullscreen() {
    const layout = document.querySelector('.split-layout');
    if (!layout) return;
    const isFs = layout.classList.toggle('fullscreen');
    const btn = document.querySelector('[onclick="togglePreviewSize()"]');
    if (btn) btn.textContent = isFs ? '⊡ Exit' : '⛶ Fullscreen';
  },

  /**
   * Extracts a lightweight text preview from stored HTML for
   * gallery card display (no iframe required).
   * @param {string} html
   * @returns {{ body: string, style: string }|null}
   */
  extractTextPreview(html) {
    const bodyMatch  = html.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
    const styleMatch = html.match(/<style[^>]*>([\s\S]*?)<\/style>/i);
    if (!bodyMatch) return null;
    return {
      body:  bodyMatch[1].substring(0, 500),
      style: styleMatch ? styleMatch[1] : '',
    };
  },
};


// ─────────────────────────────────────────────────────────────
// § 6. ChatController
//      Handles the in-page app-modification chat.
//      Each instruction goes to KivosyCore.modifyApp(); the
//      result updates the preview without a page reload.
// ─────────────────────────────────────────────────────────────

const ChatController = {
  /** Append a message bubble to the chat panel. */
  _appendMessage(role, text, isLoading = false) {
    const container = document.getElementById('chat-messages');
    if (!container) return null;

    const bubble = document.createElement('div');
    bubble.className = `chat-message ${role}`;
    bubble.style.cssText = `
      padding: 8px 12px;
      border-radius: 12px;
      font-size: 13px;
      max-width: 85%;
      word-break: break-word;
      ${role === 'user'
        ? 'background:#6366f1;color:white;align-self:flex-end;'
        : 'background:#e8f0fe;color:#1a1a1a;align-self:flex-start;'
      }
      ${isLoading ? 'opacity:0.65;' : ''}
    `;
    bubble.textContent = text;
    container.appendChild(bubble);
    container.scrollTop = container.scrollHeight;
    return bubble;
  },

  /** Clear chat and show the welcome system message. */
  reset(isExisting = false) {
    const container = document.getElementById('chat-messages');
    if (!container) return;
    container.innerHTML = '';
    
    this._appendMessage('system',
      isExisting
        ? 'App loaded. Please enter your instructions to modify it.'
        : 'App generated! You can now request changes. (e.g., "Change button color to blue" or "Add a dark mode")'
    );
  },

  /** Called when user presses Enter or clicks send. */
  async send() {
    const inputEl    = document.getElementById('chat-input');
    const instruction = inputEl?.value?.trim();
    if (!instruction) return;

    const active = Storage.session.activeApp;
    if (!active) {
      ToastSystem.show('No active app found. Please create an app first.', 'warning');
      return;
    }

    if (Storage.session.isModifying) return; 

    this._appendMessage('user', instruction);
    if (inputEl) inputEl.value = '';

    const loadingBubble = this._appendMessage('system', '⏳ AI is modifying the app...', true);

    Storage.session.setModifying(true);
    const sendBtn = document.getElementById('chat-send-btn');
    if (inputEl)  inputEl.disabled = true;
    if (sendBtn)  sendBtn.disabled = true;

    try {
      const keys = ApiKeyManager.load();
      
      if (!keys.hf) keys.hf = localStorage.getItem('hfApiKey') || JSON.parse(localStorage.getItem('kivosy_keys') || '{}').hf || '';
      if (!keys.gemini) keys.gemini = localStorage.getItem('geminiApiKey') || JSON.parse(localStorage.getItem('kivosy_keys') || '{}').gemini || '';
      if (!keys.groq) keys.groq = localStorage.getItem('groqApiKey') || JSON.parse(localStorage.getItem('kivosy_keys') || '{}').groq || '';

      const activePlatform = document.querySelector('.model-tab.active')?.dataset.platform || 'hf';
      const modelConfigs = [];

      if (keys.gemini) modelConfigs.push({ provider: 'gemini', modelId: keys.geminiModel || 'gemini-2.0-flash', apiKey: keys.gemini, priority: 1 });
      if (keys.groq) modelConfigs.push({ provider: 'groq', modelId: keys.groqModel || 'llama-3.3-70b-versatile', apiKey: keys.groq, priority: 2 });
      if (keys.hf) modelConfigs.push({ provider: 'huggingface', modelId: keys.hfModel || 'Qwen/Qwen2.5-Coder-32B-Instruct', apiKey: keys.hf, priority: 3 });

      if (modelConfigs.length === 0) throw new Error("No API keys found. Please check your Settings.");

      const result = await Core.modifyApp(
        {
          models: modelConfigs,
          onProgress: (msg) => console.log('[ChatController]', msg),
        },
        active.html,
        instruction,
        active.uuid,
        active.chatHistory?.slice(-6).map((m, i) => ({
          role: i % 2 === 0 ? 'user' : 'assistant',
          content: m,
        })) ?? []
      );

      loadingBubble?.remove();
      PreviewPanel.render(result.html);

      const usedModel = result.stats.modelUsed;
      const duration = (result.stats.durationMs / 1000).toFixed(1);

      this._appendMessage('system',
        `🚀 **Update Complete!**
         🛠️ Engine: **${usedModel}**
         ⏱️ Speed: **${duration}s**
         
         The app has been professionally tuned by our AI.`
      );

      Storage.session.appendChatMessage(instruction);
      ToastSystem.show('App updated successfully!', 'success');
      await QuotaDisplay.refresh();
      await HistoryPanel.render();

    } catch (err) {
      loadingBubble?.remove();
      const isSecurityError = err.message.includes('Security') || err.message.includes('Injection');
      
      if (isSecurityError) {
          ToastSystem.show('🛡️ Security Risk Detected!', 'warning');
          showSecurityModal(); 
      } else {
          this._appendMessage('system', `❌ Error: ${err.message}`);
          ToastSystem.show(err.message, 'error');
      }

    } finally {
      Storage.session.setModifying(false);
      if (inputEl) inputEl.disabled = false;
      if (sendBtn) sendBtn.disabled = false;
      if (inputEl) inputEl.focus();
    }
  }
};

// ─────────────────────────────────────────────────────────────
// 🛡️ [이 수석의 보안 구급함] Security Modal System
//    채팅창 낙서 대신, 깔끔하게 화면 중앙에 해결책을 띄웁니다!
// ─────────────────────────────────────────────────────────────

/** 🚨 보안 모달을 화면 중앙에 띄우는 함수 */
function showSecurityModal() {
    // 이미 모달이 떠있으면 중복 생성 방지
    if (document.getElementById('security-fix-modal')) return;

    const modalHtml = `
        <div id="security-fix-modal" style="position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.7); display:flex; justify-content:center; align-items:center; z-index:9999; backdrop-filter:blur(4px);">
            <div style="background:white; padding:32px; border-radius:20px; text-align:center; max-width:400px; width:90%; box-shadow:0 20px 40px rgba(0,0,0,0.3); animation: fadeIn 0.3s ease-out;">
                <div style="font-size:48px; margin-bottom:16px;">🛡️</div>
                <h3 style="margin:0 0 12px; color:#cf1322; font-size:20px;">Security Policy Blocked</h3>
                <p style="font-size:14px; color:#555; line-height:1.6; margin-bottom:28px;">
                    The AI attempted to generate code that triggers security filters. 
                    Let's sanitize the request to continue building safely.
                </p>
                <button onclick="confirmAutoFix()" style="background:#ff4d4f; color:white; border:none; padding:14px 0; border-radius:10px; cursor:pointer; font-weight:bold; width:100%; font-size:15px; transition:all 0.2s;">
                    🔄 Auto-Fix & Retry
                </button>
                <button onclick="document.getElementById('security-fix-modal').remove()" style="background:none; border:none; color:#999; margin-top:16px; cursor:pointer; font-size:12px; text-decoration:underline;">
                    Ignore and Close
                </button>
            </div>
        </div>
        <style>
            @keyframes fadeIn { from { opacity: 0; transform: translateY(-20px); } to { opacity: 1; transform: translateY(0); } }
        </style>
    `;
    document.body.insertAdjacentHTML('beforeend', modalHtml);
}

/** 🛠️ 사용자가 [Auto-Fix] 버튼을 눌렀을 때 실행될 로직 */
window.confirmAutoFix = () => {
    // 1. 모달 닫기
    document.getElementById('security-fix-modal')?.remove();
    
    // 2. 입력창에 '안전한 가이드' 주입
    const inputEl = document.getElementById('chat-input');
    if (inputEl) {
        inputEl.value = "Apply the previous request again, but strictly avoid using restricted browser APIs or unsafe HTML patterns. Ensure the code is secure and follows standard web practices.";
        
        // 3. 재전송 시뮬레이션
        ChatController.send();
        ToastSystem.show('Retrying with safety guidelines...', 'info');
    }
};


// ─────────────────────────────────────────────────────────────
// § 7. HistoryPanel
//      Renders the "생성된 앱 목록" section on index.html.
// ─────────────────────────────────────────────────────────────

const HistoryPanel = {
  async render() {
    const list = document.getElementById('app-history-list');
    if (!list) return;

    const apps = await Storage.apps.getIndex();

    if (apps.length === 0) {
      // 🎯 여기를 수정!
      list.innerHTML = '<div class="history-empty">No apps yet. Create your first one!</div>';
      return;
    }

    list.innerHTML = apps.map(app => {
      // 🎯 날짜 포맷도 글로벌하게 (ko-KR -> en-US)
      const date = new Date(app.createdAt).toLocaleString('en-US', {
        month: 'short',    // Feb
        day: '2-digit',    // 22
        year: 'numeric',   // 2026
        hour: '2-digit',   // 10
        minute: '2-digit', // 40
        hour12: true       // AM/PM
      });
      const favIcon = app.isFavorite ? '⭐' : '☆';
      const tags = (app.tags || []).slice(0, 2).map(t => `<span style="font-size:10px;background:#f0f0ff;color:#6366f1;padding:2px 6px;border-radius:99px;">${t}</span>`).join('');
      return `
      <div class="history-item" data-uuid="${app.uuid}">
        <div class="history-item-info">
          <div class="history-item-prompt" title="${app.prompt}">${app.prompt}</div>
          <div class="history-item-meta">
            ID: ${app.uuid.slice(0, 8)} &nbsp;|&nbsp;
            ${app.sizeKB}KB &nbsp;|&nbsp;
            ${date} &nbsp;|&nbsp;
            Rev.${app.revision ?? 1}
          </div>
        </div>
        <div class="history-item-actions">
          <button class="history-action-btn h-open" onclick="UIEngine.openApp('${app.uuid}')">🚀 Open</button>
          <button class="history-action-btn h-open" onclick="UIEngine.loadAppToEditor('${app.uuid}')">💬 Edit</button>
          <button class="history-action-btn h-open" onclick="UIEngine.publishApp('${app.uuid}')" title="Publish to Gallery">🌐</button>
          </div>
      </div>`;
    }).join('');
  },
};


// ─────────────────────────────────────────────────────────────
// § 8. FactoryController
//      Handles the main generation flow on index.html.
// ─────────────────────────────────────────────────────────────

const FactoryController = {
  /** Main handler wired to the ⚡ 앱 생성하기 button. */
  async generate() {
    const promptEl = document.getElementById('factory-prompt');
    const prompt   = promptEl?.value?.trim();

    if (!prompt) {
      ToastSystem.show('Please enter a description for your app.', 'warning');
      promptEl?.focus();
      return;
    }

    // 🎯 [정리] 키 로드 (ApiKeyManager에서 한 번에 가져오기)
    const keys = ApiKeyManager.load();
    
    // 만약 로드된 키가 없으면 개별 저장소 확인 (공장장님 보험 코드)
    if (!keys.hf) {
        keys.hf = localStorage.getItem('hfApiKey') || 
                  JSON.parse(localStorage.getItem('kivosy_keys') || '{}').hf || '';
    }

    if (!keys.gemini && !keys.groq && !keys.hf) {
      ToastSystem.show('Please configure your API keys first. (Click 🔑 icon)', 'warning', 4000);
      ApiKeyManager.showModal();
      return;
    }

    // UI 잠금 및 상태 표시
    const btn     = document.getElementById('factory-generate-btn');
    const spinner = document.getElementById('factory-spinner');
    const btnText = document.getElementById('factory-btn-text');
    const errorEl = document.getElementById('factory-error');
    const resultEl = document.getElementById('factory-result');

    btn.disabled         = true;
    spinner.style.display = 'block';
    btnText.textContent  = 'Generating...';
    errorEl.style.display = 'none';
    resultEl.style.display = 'none';
    ProgressPanel.show();

    try {
      // 🎯 [실시간 모델 매칭] 사용자가 화면에서 선택한 값 읽기
      const selectedProvider = document.querySelector('input[name="provider-select"]:checked')?.value || 'all';
      const modelConfigs = [];

      // 1. Gemini
      if (keys.gemini && (selectedProvider === 'all' || selectedProvider === 'gemini')) {
        modelConfigs.push({
          provider: 'gemini',
          modelId:  document.getElementById('gemini-model-select')?.value || 'gemini-2.0-flash-exp', 
          apiKey:   keys.gemini,
          priority: 1
        });
      }

      // 2. Groq
      if (keys.groq && (selectedProvider === 'all' || selectedProvider === 'groq')) {
        modelConfigs.push({
          provider: 'groq',
          modelId:  document.getElementById('groq-model-select')?.value || 'llama-3.3-70b-versatile',
          apiKey:   keys.groq,
          priority: 2
        });
      }

      // 3. HuggingFace
      if (keys.hf && (selectedProvider === 'all' || selectedProvider === 'huggingface')) {
        modelConfigs.push({
          provider: 'huggingface',
          modelId:  document.getElementById('hf-model-select')?.value || 'Qwen/Qwen2.5-Coder-32B-Instruct',
          apiKey:   keys.hf,
          priority: 3
        });
      }

      

      
//==============================================================
      // 추후 무료 모델 추가할시 4번으로 연결할것
//==============================================================

      // 🎯 최종 모델 투입 전 검증
      if (modelConfigs.length === 0) {
        throw new Error(selectedProvider === 'all' ? "No API keys found." : `Please enter the key for ${selectedProvider}.`);
      }

      // 엔진 가동!
      const result = await Core.generateApp({
          models: modelConfigs,
          onProgress: (msg) => ProgressPanel.addStep(msg),
        },
        prompt
      );


      ProgressPanel.hide();
      PreviewPanel.render(result.html);

      const metaEl = document.getElementById('result-meta');
      if (metaEl) {
        metaEl.innerHTML = 
          `App ID: ${result.uuid.slice(0, 8)}  ·  ` +
          `Size: ${result.stats.sizeKB}KB  ·  ` +
          `Model: <strong>${result.stats.modelUsed}</strong>  ·  ` +
          `Created: ${new Date(result.metadata.createdAt).toLocaleString('en-US')}`;
      }

      resultEl.style.display = 'block';
      resultEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
      ChatController.reset(false);

      await QuotaDisplay.refresh();
      await HistoryPanel.render();
      if (Storage.usage) await Storage.usage.recordCall(result.stats.modelUsed);
      if (window.UIEngine && UIEngine.refreshUsageDashboard) await UIEngine.refreshUsageDashboard();

      ToastSystem.show(`App generated! (${result.stats.modelUsed})`, 'success');

    } catch (err) {
      ProgressPanel.hide();
      const isSecurityError = err.message.includes('Security');
      
      const fixButtonHtml = isSecurityError 
        ? `<div style="margin-bottom:15px; padding:15px; background:#eef2ff; border-radius:10px; border:1px solid #6366f1;">
            <button onclick="autoFixSecurityIssue()" style="width:100%; background:#4f46e5; color:white; border:none; padding:12px; border-radius:6px; cursor:pointer; font-weight:bold; font-size:14px;">🔄 Fix Security Issues & Retry Now</button>
            <p style="font-size:11px; color:#4338ca; margin-top:8px; margin-bottom:0;">* 이 버튼을 누르면 보안 가이드가 자동으로 프롬프트에 추가됩니다.</p>
          </div>`
        : '';

      // ✨ 포인트: 에러 글자(d93025 색상)보다 버튼 박스가 먼저 나옵니다!
      errorEl.innerHTML = `${fixButtonHtml}<div style="color:#d93025; font-size:13px;">⚠️ ${err.message}</div>`;
      errorEl.style.display = 'block';
      
      ToastSystem.show(isSecurityError ? '🔒 Security Blocked' : err.message, 'error', 6000);
    } finally {
      btn.disabled          = false;
      spinner.style.display = 'none';
      btnText.textContent   = '⚡ Create App';
    }
  },

  setPrompt(text) {
    const ta = document.getElementById('factory-prompt');
    if (ta) { ta.value = text; ta.focus(); }
  },
};


// ─────────────────────────────────────────────────────────────
// § 9. GalleryController (Global Version)
// ─────────────────────────────────────────────────────────────

const GalleryController = {
  _allApps: [],

  async load() {
    const grid = document.getElementById('gallery-grid');
    if (!grid) return;

    this._allApps = await Storage.apps.getIndex();

    const appCountEl = document.getElementById('app-count');
    const todayCountEl = document.getElementById('today-count');
    
    if (appCountEl) appCountEl.textContent = this._allApps.length;
    if (todayCountEl) {
      const today = new Date().toISOString().slice(0, 10);
      todayCountEl.textContent = this._allApps.filter(a => a.createdAt.startsWith(today)).length;
    }

    this._render(this._allApps);
  },

  filter() {
    const q = document.getElementById('search-input')?.value.toLowerCase().trim() || '';
    const filtered = q
      ? this._allApps.filter(a =>
          a.prompt.toLowerCase().includes(q) ||
          (a.tags || []).some(t => t.toLowerCase().includes(q))
        )
      : this._allApps;
    this._render(filtered);
  },

  // 🎯 키워드 맵을 영문 중심으로 업데이트!
  _detectType(prompt) {
    const p = prompt.toLowerCase();
    const map = [
      [['todo', 'task', 'list', '할일'],       { icon:'✅', type:'To-do App',   color:'#3b82f6' }],
      [['calc', 'math', '계산기'],            { icon:'🧮', type:'Calculator',  color:'#10b981' }],
      [['weather', 'forecast', '날씨'],       { icon:'☀️', type:'Weather App', color:'#f59e0b' }],
      [['note', 'memo', '노트', '메모'],       { icon:'📝', type:'Notebook',    color:'#8b5cf6' }],
      [['chat', 'messenger', '채팅'],         { icon:'💬', type:'Chat App',    color:'#ec4899' }],
      [['game', 'quiz', 'play', '게임'],      { icon:'🎮', type:'Game/Quiz',   color:'#f43f5e' }],
      [['timer', 'clock', 'stopwatch'],      { icon:'⏱️', type:'Timer/Clock', color:'#0ea5e9' }],
    ];
    for (const [keywords, meta] of map) {
      if (keywords.some(k => p.includes(k))) return meta;
    }
    return { icon:'📱', type:'General App', color:'#6366f1' }; // 일반 앱 -> General App
  },

  _render(apps) {
    const grid = document.getElementById('gallery-grid');
    if (!grid) return;

    if (apps.length === 0) {
      grid.innerHTML = `
        <div class="gallery-empty">
          <div style="font-size:48px;margin-bottom:16px;">🏗️</div>
          <p style="margin-bottom:20px;">No applications found yet.</p>
          <a href="index.html" style="color:var(--indigo); font-weight:600;">Build your first app →</a>
        </div>`;
      return;
    }

    grid.innerHTML = apps.map(app => {
      const type = this._detectType(app.prompt);
      // 🎯 날짜 포맷을 미국식(글로벌)으로 변경
      const date = new Date(app.createdAt).toLocaleString('en-US', {
        month: 'short',    // Feb
        day: '2-digit',    // 22
        year: 'numeric',   // 2026
        hour: '2-digit',   // 09
        minute: '2-digit', // 43
        hour12: true       // AM/PM 표시
      });
      
      const promptLine = app.prompt.split('\n')[0];
      const preview = promptLine.length > 42 ? promptLine.slice(0, 42) + '…' : promptLine;
      const favIcon = app.isFavorite ? '⭐' : '☆';
      const tagHtml = (app.tags || []).slice(0, 3).map(t =>
        `<span class="feature-tag">${t}</span>`
      ).join('');

      return `
      <div class="gallery-card" data-uuid="${app.uuid}">
        <div class="app-preview" onclick="UIEngine.openApp('${app.uuid}')" style="cursor:pointer;">
          <div class="preview-header">
            <span class="preview-dot" style="background:#ff5f56"></span>
            <span class="preview-dot" style="background:#ffbd2e"></span>
            <span class="preview-dot" style="background:#27c93f"></span>
            <span class="preview-title">Preview Screen</span> </div>
          <div class="preview-content">
            <div style="display:flex;align-items:center;justify-content:center;height:70px;flex-direction:column;gap:8px;">
              <span style="font-size:32px;">${type.icon}</span>
              <span style="font-size:11px;color:#94a3b8;">${type.type}</span>
            </div>
          </div>
        </div>

        <div style="padding:16px 16px 16px;">
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:12px;">
            <div style="width:32px;height:32px;background:${type.color}20;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:18px;">${type.icon}</div>
            <div style="flex:1;">
              <div style="font-size:15px;font-weight:600;color:#1e293b;">${type.type}</div>
              <div style="font-size:10px;color:#94a3b8;">🆔 ${app.uuid.slice(0, 8)} · Rev.${app.revision ?? 1}</div>
            </div>
            <button onclick="UIEngine.galleryToggleFavorite('${app.uuid}')" 
              style="background:none;border:none;font-size:18px;cursor:pointer;padding:4px;" title="Favorite">${favIcon}</button>
          </div>

          <div class="card-prompt">"${preview}"</div>

          ${tagHtml ? `<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:12px;">${tagHtml}</div>` : ''}

          <div class="card-meta">
            <span>📅 ${date}</span>
            <span>📦 ${app.sizeKB}KB</span>
          </div>

          <div class="gallery-actions">
            <button onclick="UIEngine.openApp('${app.uuid}')" class="gallery-btn primary">🚀 Run</button> <button onclick="UIEngine.copyPrompt('${app.uuid}')" class="gallery-btn secondary" title="Copy Prompt">📋</button>
            <button onclick="UIEngine.galleryPublish('${app.uuid}')" class="gallery-btn secondary" title="Deploy App" style="background:#f0f0ff;color:#6366f1;">🌐</button>
            <button onclick="UIEngine.deleteApp('${app.uuid}')" class="gallery-btn danger" title="Delete">🗑️</button>
          </div>
        </div>
      </div>`;
    }).join('');
  },
};

// 🚀 [KIVOSY Auto-Fixer] 보안 가이드를 프롬프트에 자동 주입하고 재시도하는 함수
window.autoFixSecurityIssue = function() {
    // 1. 입력창 찾기 (생성용/수정용 구분)
    const factoryInput = document.getElementById('factory-prompt');
    const chatInput = document.getElementById('chat-input');
    
    // 2. 현재 활성화된 입력창에 보안 가이드 주입
    if (factoryInput && factoryInput.offsetParent !== null) {
        factoryInput.value += "\n\n(Note: Please ensure the code does not use document.cookie or restricted storage APIs for security.)";
        // 모달/토스트가 있다면 닫고 바로 생성 버튼 클릭
        document.getElementById('factory-generate-btn')?.click();
    } else if (chatInput) {
        chatInput.value = "Fix it without using cookies or sensitive APIs.";
        document.getElementById('chat-send-btn')?.click();
    }
    
    console.log("🛡️ Security Patch Applied: Regenerating safe code...");
};


// ─────────────────────────────────────────────────────────────
// § 10. UIEngine — Public Orchestrator
//       Single object exposed on window. Wires everything up
//       and exposes the functions called from inline HTML onclick.
// ─────────────────────────────────────────────────────────────

const UIEngine = {
  // ── Boot ─────────────────────────────────────────────────

  async init() {
    const page = this._detectPage();

    // 🎯 접속하자마자 사용량 계산
    if (Storage.usage && typeof Storage.usage.getDailyStats === 'function') {
      await this.refreshUsageDashboard();
    }

    if (page === 'factory') {
      await this._initFactory();
    } else if (page === 'gallery') {
      await GalleryController.load();
    }

    // Subscribe to session state changes to keep UI reactive
    Storage.session.on('isGenerating', (v) => {
      const btn = document.getElementById('factory-generate-btn');
      if (btn) btn.disabled = v;
    });
    Storage.session.on('isModifying', (v) => {
      const chatInput = document.getElementById('chat-input');
      const sendBtn   = document.getElementById('chat-send-btn');
      if (chatInput) chatInput.disabled = v;
      if (sendBtn)   sendBtn.disabled   = v;
    });
  },

  _detectPage() {
    if (document.getElementById('factory-prompt'))  return 'factory';
    if (document.getElementById('gallery-grid'))    return 'gallery';
    return 'unknown';
  },

  async _initFactory() {
    await QuotaDisplay.refresh();
    await HistoryPanel.render();
    this._wireApiKeyModal();
  },

  _wireApiKeyModal() {
    window.showApiKeyModal  = () => ApiKeyManager.showModal();
    window.closeApiKeyModal = () => ApiKeyManager.closeModal();
    window.saveApiKeys      = () => ApiKeyManager.saveFromModal();
  },

  // ── Factory actions ────────────────────────────────────────
  generate:   () => FactoryController.generate(),
  setPrompt:  (t) => FactoryController.setPrompt(t),
  sendChat:   () => ChatController.send(),
  refreshPreview:    () => PreviewPanel.refresh(),
  togglePreviewSize: () => PreviewPanel.toggleFullscreen(),

  async handleOpenApp() {
    const active = Storage.session.activeApp;
    if (active?.uuid) await this.openApp(active.uuid);
  },

  async handleCopyCode() {
    const active = Storage.session.activeApp;
    if (!active?.html) return;
    
    await navigator.clipboard.writeText(active.html);
    const btn = document.getElementById('result-copy-btn');
    if (btn) {
      const orig = btn.textContent;
      btn.textContent = '✅ Copied!'; // 영문화
      setTimeout(() => (btn.textContent = orig), 1600);
    }
    ToastSystem.show('Code copied to clipboard!', 'copy'); // 영문화
  },

  async handleDeleteApp() {
    const active = Storage.session.activeApp;
    if (!active) return;
    if (!confirm('Are you sure you want to delete this app?')) return; // 영문화
    
    await this.deleteApp(active.uuid);
    Storage.session.clearActiveApp();
    document.getElementById('factory-result').style.display = 'none';
  },

  // ui.js의 UIEngine 객체 내부에 추가
  toggleModelSubSelect(provider) {
    const container = document.getElementById('model-sub-options');
    const groups = document.querySelectorAll('.sub-opt-group');
    
    // 1. 모든 상세 옵션 그룹 일단 숨기기
    groups.forEach(g => g.style.display = 'none');
    
    // 2. 'all' 선택 시 패널 자체를 숨김
    if (provider === 'all') {
      container.style.display = 'none';
      return;
    }
    
    // 3. 선택된 브랜드의 옵션만 보여주기
    const target = document.getElementById(`${provider}-opts`);
    if (target) {
      container.style.display = 'block';
      target.style.display = 'block';
    }
  },

  
  async openApp(uuid) {
    try {
      await Core.openApp(uuid);
    } catch (err) {
      ToastSystem.show(err.message, 'error');
    }
  },

  async loadAppToEditor(uuid) {
    const html = await Storage.apps.getHtml(uuid);
    const meta = await Storage.apps.getMeta(uuid);
    if (!html || !meta) {
      ToastSystem.show('App not found.', 'error'); // 영문화
      return;
    }

    Storage.session.setActiveApp({ uuid, html, isDirty: false, chatHistory: [] });
    PreviewPanel.render(html);

    const metaEl = document.getElementById('result-meta');
    if (metaEl) {
      metaEl.textContent =
        `App ID: ${uuid.slice(0, 8)}  ·  Size: ${meta.sizeKB}KB  ·  ` +
        `Created: ${new Date(meta.createdAt).toLocaleString('en-US', {
          month: 'short',
          day: '2-digit', 
          year: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
          hour12: true
        })}`;
    }

    ChatController.reset(true);
    const resultEl = document.getElementById('factory-result');
    if (resultEl) {
      resultEl.style.display = 'block';
      resultEl.scrollIntoView({ behavior: 'smooth' });
    }

    ToastSystem.show('App loaded into editor.', 'info'); // 영문화
  },

  async deleteApp(uuid) {
    if (!confirm('Permanently delete this application?')) return; // 영문화
    await Storage.apps.delete(uuid);
    await HistoryPanel.render();
    if (window.GalleryController) await GalleryController.load();
    ToastSystem.show('Application deleted.', 'info'); // 영문화
  },

  async toggleFavorite(uuid, source = 'history') {
    const isFav = await Storage.apps.toggleFavorite(uuid);
    
    // 소스에 따라 UI 새로고침 분기 (함수 하나로 통합)
    if (source === 'gallery') {
      await GalleryController.load();
    } else {
      await HistoryPanel.render();
    }
    
    ToastSystem.show(isFav ? 'Added to favorites ⭐' : 'Removed from favorites', 'info'); // 영문화
  },

  async galleryToggleFavorite(uuid) {
    const isFav = await Storage.apps.toggleFavorite(uuid);
    await GalleryController.load();
    ToastSystem.show(isFav ? '즐겨찾기에 추가됐습니다. ⭐' : '즐겨찾기를 해제했습니다.', 'info');
  },

  async copyPrompt(uuid) {
    const meta = await Storage.apps.getMeta(uuid);
    if (!meta) return;
    await navigator.clipboard.writeText(meta.prompt);
    ToastSystem.show('Prompt copied!', 'copy'); // 영문화
  },

  async publishApp(uuid) {
    const meta = await Storage.apps.getMeta(uuid);
    if (!meta) return;
    await Storage.apps.updateTags(uuid, 'published', 'add');
    ToastSystem.show('🚀 Ready to Publish! Global Gallery coming soon.', 'publish', 5000); // 영문화
  },

  async galleryPublish(uuid) { return this.publishApp(uuid); },

  filterGallery: () => GalleryController.filter(),
  refreshQuota: () => QuotaDisplay.refresh(),
  renderAppHistory: () => HistoryPanel.render(),

  async refreshUsageDashboard() {
    // HTML에 있는 컨테이너 ID 확인 (usage-mini-charts 또는 miniChartContainer)
    const container = document.querySelector('.usage-mini-charts') || document.getElementById('miniChartContainer');
    if (!container) return;

    const stats = await Storage.usage.getDailyStats();
    const total = Object.values(stats).reduce((a, b) => a + b, 0);

    if (total === 0) {
      container.innerHTML = '<span style="font-size:11px; color:#94a3b8; font-weight:500;">Ready to Build</span>';
      return;
    }

    container.innerHTML = Object.entries(stats).map(([model, count]) => {
      // 막대기 길이는 상대적 비율로 표시
      const percent = Math.max((count / total * 100), 12).toFixed(0);
      
      // 🎯 이 수석의 시크한 무채색 팔레트
      let color = '#334155'; // Gemini (진한 차콜)
      if (model.includes('groq')) color = '#64748b';        // Groq (미드 그레이)
      if (model.includes('hugging')) color = '#94a3b8';     // HF (라이트 그레이)
      if (model.includes('other')) color = '#cbd5e1';       // 기타 (실버)

      return `
        <div class="mini-bar-wrapper" title="${model.toUpperCase()}: ${count} calls" style="display:inline-flex; align-items:center; margin-right:15px;">
          <div class="mini-bar" style="width: ${percent}px; background: ${color}; height:6px; border-radius:3px; transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);"></div>
          <span style="font-size:10px; margin-left:6px; color: #475569; font-weight: 700;">${count}</span>
        </div>
      `;
    }).join('');
  },

  // UI.js의 openUsageStats를 이렇게 업데이트하세요!
  openUsageStats: async function() {
      // 1. 공장장님의 Storage 엔진에서 직접 데이터 가져오기
      if (!window.KivosyStorage || !window.KivosyStorage.usage) {
          alert("Storage system is not ready.");
          return;
      }

      const stats = await window.KivosyStorage.usage.getDailyStats();
      const total = Object.values(stats).reduce((a, b) => a + b, 0);

      // 2. 무제한 모드 UI 생성
      const statsHtml = `
          <div style="padding: 24px; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;">
              <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 20px;">
                  <span style="font-size: 24px;">🚀</span>
                  <h3 style="margin: 0; color: #1e293b; font-size: 20px;">KIVOSY Production Line</h3>
              </div>
              
              <div style="background: linear-gradient(135deg, #6366f1 0%, #a855f7 100%); padding: 20px; border-radius: 16px; color: white; margin-bottom: 20px; box-shadow: 0 10px 15px -3px rgba(99,102,241,0.3);">
                  <p style="margin: 0; font-size: 13px; opacity: 0.9;">Today's Total Workload</p>
                  <div style="font-size: 36px; font-weight: 800; margin: 4px 0;">${total} <span style="font-size: 16px; font-weight: 400; opacity: 0.8;">Calls</span></div>
                  <div style="font-size: 11px; background: rgba(255,255,255,0.2); display: inline-block; padding: 2px 8px; border-radius: 20px;">♾️ Unlimited Mode Active</div>
              </div>

              <div style="background: #f8fafc; border-radius: 12px; padding: 16px; border: 1px solid #e2e8f0;">
                  <p style="font-size: 13px; font-weight: 700; color: #475569; margin-bottom: 12px;">Model Statistics (Today)</p>
                  ${Object.keys(stats).length > 0 
                      ? Object.entries(stats).map(([p, c]) => `
                          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px; padding-bottom:6px; border-bottom:1px dashed #e2e8f0;">
                              <span style="text-transform:uppercase; font-size:12px; font-weight:600; color:#64748b;">${p}</span>
                              <span style="font-family:monospace; font-weight:700; color:#1e293b;">${c}</span>
                          </div>`).join('')
                      : '<p style="font-size: 12px; color: #94a3b8; text-align: center; margin: 10px 0;">No production logs yet.</p>'
                  }
              </div>

              <button onclick="this.closest('.kivosy-modal-overlay').remove()" 
                      style="margin-top:20px; width:100%; padding:14px; border:none; background:#1e293b; color:white; border-radius:10px; font-weight:600; cursor:pointer;">
                  Close Dashboard
              </button>
          </div>
      `;

      // 3. 화면 렌더링 (모달)
      const overlay = document.createElement('div');
      overlay.className = 'kivosy-modal-overlay';
      overlay.style = "position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(15, 23, 42, 0.7); display:flex; align-items:center; justify-content:center; z-index:10000; backdrop-filter: blur(8px);";
      
      const content = document.createElement('div');
      content.style = "background:white; border-radius:24px; width:340px; overflow:hidden; box-shadow:0 25px 50px -12px rgba(0,0,0,0.5);";
      content.innerHTML = statsHtml;

      // 💡 [핵심] 외부(overlay) 클릭 시 닫기 로직
      overlay.onclick = (e) => {
          if (e.target === overlay) { 
              overlay.remove(); 
          }
      };
        
      overlay.appendChild(content);
      document.body.appendChild(overlay);
  }
};



// ─────────────────────────────────────────────────────────────
// § 11. Global function shims
//       Existing HTML onclick="" attributes call these names.
//       Rather than rewrite index.html/gallery.html, we map
//       each legacy name to the new UIEngine method.
// ─────────────────────────────────────────────────────────────

window.handleFactoryGenerate = () => UIEngine.generate();
window.setFactoryPrompt      = (t) => UIEngine.setPrompt(t);
window.sendChat              = () => UIEngine.sendChat();
window.refreshPreview        = () => UIEngine.refreshPreview();
window.togglePreviewSize     = () => UIEngine.togglePreviewSize();
window.handleOpenApp         = () => UIEngine.handleOpenApp();
window.handleCopyCode        = () => UIEngine.handleCopyCode();
window.handleDeleteApp       = () => UIEngine.handleDeleteApp();
window.renderAppHistory      = () => UIEngine.renderAppHistory();
window.loadAppToChat         = (uuid) => UIEngine.loadAppToEditor(uuid);
window.filterGallery         = () => UIEngine.filterGallery();
window.sendChat              = () => ChatController.send();

// ─────────────────────────────────────────────────────────────
// § 12. Bootstrap — Engine Start
// ─────────────────────────────────────────────────────────────
window.UIEngine = UIEngine;

document.addEventListener('DOMContentLoaded', () => {
  UIEngine.init().catch(err => {
    console.error('[UIEngine] Boot failed:', err);
    // [영문화] 초기화 오류 메시지
    ToastSystem.show('An error occurred during UI initialization.', 'error');
  });
});

