/**
 * KIVOSY Studio - Core App Logic
 */

const STORAGE_KEY = 'kivosy_keys';

/* -----------------------------------------------------------
   A. Helper Functions
   ----------------------------------------------------------- */

// 1. loadKeysIntoUI 수정
function loadKeysIntoUI() {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
        try {
            const keys = JSON.parse(saved);
            
            const g = document.getElementById('gemini-key');
            const gr = document.getElementById('groq-key');
            const h = document.getElementById('hf-key');

            if (g) g.value = keys.gemini ? '********************' : '';
            if (gr) gr.value = keys.groq ? '********************' : '';
            if (h) h.value = keys.hf ? '********************' : '';
            
            // [수정] 모델 경로 로드 - 신버전 ID 사용
            if (keys.geminiModel) document.getElementById('gemini-model-select').value = keys.geminiModel;
            if (keys.groqModel)   document.getElementById('groq-model-select').value = keys.groqModel;
            if (keys.hfModel)     document.getElementById('hf-model-select').value = keys.hfModel;

            console.log("Keys and Models loaded from:", STORAGE_KEY);
        } catch (e) {
            console.error("JSON Parsing error", e);
        }
    }
}

// 2. deleteApiKeys 수정
window.deleteApiKeys = function() {
    if (confirm('⚠️ All API keys and configurations will be permanently deleted. Proceed?')) {
        localStorage.removeItem(STORAGE_KEY);
        
        // [수정] inputs 배열 - 신버전 ID 사용
        const inputs = ['gemini-key', 'groq-key', 'hf-key', 'gemini-model-select', 'groq-model-select', 'hf-model-select'];
        inputs.forEach(id => {
            const el = document.getElementById(id);
            if (el) {
                if (id.includes('model')) {
                    // 모델 select의 기본값 설정
                    if (id.includes('gemini')) el.value = 'gemini-2.0-flash';
                    else if (id.includes('groq')) el.value = 'llama-3.3-70b-versatile';
                    else if (id.includes('hf')) el.value = 'Qwen/Qwen2.5-Coder-32B-Instruct';
                } else {
                    el.value = '';
                }
            }
        });

        alert('All settings have been cleared. 🧹');
        closeApiKeyModal();
    }
};


// 3. setModel 함수 업데이트 (이미 있는 window.setModel 재정의)
window.setModel = function(id, val) {
    // [추가] 구버전 ID를 신버전으로 변환
    let actualId = id;
    if (id === 'gemini-model') actualId = 'gemini-model-select';
    if (id === 'groq-model') actualId = 'groq-model-select';
    if (id === 'hf-model') actualId = 'hf-model-select';
    
    const el = document.getElementById(actualId);
    if (el) {
        el.value = val;
        el.style.borderColor = 'var(--indigo)';
        setTimeout(() => el.style.borderColor = '', 500);
    }
};

/* -----------------------------------------------------------
   B. API Modal System
   ----------------------------------------------------------- */

function injectApiKeyModal() {
    if (document.getElementById('api-key-modal')) return;

    const modalHtml = `
    <div id="api-key-modal" class="modal">
        <div class="modal-content">
            <span class="close-btn" onclick="closeApiKeyModal()">&times;</span>
            <div class="modal-body">
                <h2 style="margin-bottom: 8px;">🔑 API Settings</h2>
                <div class="modal-header-text" style="margin-bottom: 16px;">
                    <p style="font-size: 13px; color: var(--text-secondary); margin: 0;">Configure your free providers.</p>
                    <p style="font-size: 12px; color: var(--indigo); font-weight: 600; display: flex; align-items: center; gap: 4px; margin-top: 4px;">
                        <span>🔒</span> Keys are stored safely in your browser.
                    </p>
                </div>

                <div class="modal-sections-container">
                    <div style="font-size: 11px; font-weight: 800; color: var(--indigo); margin-bottom: 12px; text-transform: uppercase; letter-spacing: 1px;">
                        🆓 Available Free Tier
                    </div>
                    <div class="settings-section">
                        <div class="section-header">
                            <span class="provider-name">Google Gemini</span>
                            <a href="https://aistudio.google.com/" target="_blank" class="header-link">🔗 AI Studio</a>
                            <a href="guide-gemini.html" target="_blank" class="header-link secondary">📄 Guide</a>
                            <span class="badge-free">FREE</span>
                        </div>
                        <div class="input-item" style="position: relative;">
                            <label>API Key</label>
                            <input type="password" id="gemini-key" placeholder="AIza...">
                            <button type="button" class="toggle-eye" onclick="togglePassword('gemini-key', this)">
                                <span class="material-icons">visibility</span>
                            </button>
                        </div>
                        <div class="input-item">
                            <label>Main Model Path</label>
                            <input type="text" id="gemini-model-select" value="models/gemini-2.5-flash">
                        </div>
                    </div>

                    <hr class="section-divider">

                    <div class="settings-section">
                        <div class="section-header">
                            <span class="provider-name">Groq (Llama)</span>
                            <a href="https://console.groq.com/keys" target="_blank" class="header-link">🔗 Groq Cloud</a>
                            <a href="guide-groq.html" target="_blank" class="header-link secondary">📄 Guide</a>
                            <span class="badge-free">FREE</span>
                        </div>
                        <div class="input-item" style="position: relative;">
                            <label>API Key</label>
                            <input type="password" id="groq-key" placeholder="gsk_...">
                            <button type="button" class="toggle-eye" onclick="togglePassword('groq-key', this)">
                                <span class="material-icons">visibility</span>
                            </button>
                        </div>
                        <div class="input-item">
                            <label>Main Model Path</label>
                            <input type="text" id="groq-model-select" value="llama-3.3-70b-versatile">
                            <div class="playground-presets">
                                <span class="preset-label">Labs:</span>
                                <button type="button" class="preset-btn" onclick="setModel('groq-model-select', 'llama-3.3-70b-versatile')"> Llama 3.3 (Main) </button>
                                <button type="button" class="preset-btn" onclick="setModel('groq-model-select', 'llama-3.1-8b-instant')"> Llama 3.1 (Fast) </button>
                                <button type="button" class="preset-btn" onclick="setModel('groq-model-select', 'qwen/qwen3-32b')"> Qwen 3 (Logic) </button>                                 
                            </div>
                        </div>
                    </div>

                    <hr class="section-divider">

                    <div class="settings-section">
                        <div class="section-header">
                            <span class="provider-name">Hugging Face</span>
                            <a href="https://huggingface.co/settings/tokens" target="_blank" class="header-link">🔗 Tokens</a>
                            <a href="guide-huggingface.html" target="_blank" class="header-link secondary">📄 Guide</a>
                            <span class="badge-free">FREE</span>
                        </div>
                        <div class="input-item" style="position: relative;">
                            <label>API Key</label>
                            <input type="password" id="hf-key" placeholder="hf_...">
                            <button type="button" class="toggle-eye" onclick="togglePassword('hf-key', this)">
                                <span class="material-icons">visibility</span>
                            </button>
                        </div>
                        <div class="input-item">
                            <label>Main Model Path</label>
                            <input type="text" id="hf-model-select" value="Qwen/Qwen2.5-72B-Instruct">
                            <div class="playground-presets">
                                <span class="preset-label">Labs:</span>
                                <button type="button" class="preset-btn" onclick="setModel('hf-model-select', 'Qwen/Qwen2.5-72B-Instruct')">Qwen 2.5</button>
                                <button type="button" class="preset-btn" onclick="setModel('hf-model-select', 'deepseek-ai/DeepSeek-R1-Distill-Qwen-32B')">DS Qwen</button>
                                <button type="button" class="preset-btn" onclick="setModel('hf-model-select', 'meta-llama/Llama-3.3-70B-Instruct')">Llama 3.3</button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal-actions" style="margin-top: 20px; display: flex; gap: 10px;">
                    <button class="modal-btn primary" onclick="saveApiKeys()" style="flex: 2;">Save Configuration</button>
                    <button class="modal-btn delete-btn" onclick="deleteApiKeys()" style="flex: 1;">Delete All</button>
                </div>
            </div>
        </div>
    </div>`;

    document.body.insertAdjacentHTML('beforeend', modalHtml);
    
    loadKeysIntoUI();
}

// 👁️ 진짜 키를 보여주는 스마트 토글 함수
window.togglePassword = function(id, btn) {
    const input = document.getElementById(id);
    const icon = btn.querySelector('.material-icons');
    
    if (input.type === 'password') {
        // 1. 텍스트 모드로 전환
        input.type = 'text';
        icon.textContent = 'visibility_off';

        // 2. 💡 만약 현재 값이 마스킹(***) 상태라면 저장소에서 진짜 키를 가져옴
        if (input.value.includes('*')) {
            const saved = localStorage.getItem(STORAGE_KEY);
            if (saved) {
                const keys = JSON.parse(saved);
                // ID가 'gemini-key'이면 'gemini'를 추출
                const provider = id.replace('-key', ''); 
                
                // 스토리지에 진짜 키가 있다면 그 값을 입력창에 주입
                if (keys[provider]) {
                    input.value = keys[provider];
                } else {
                    // 키가 없으면 그냥 비워줌 (보안상 별표 제거)
                    input.value = '';
                }
            }
        }
    } else {
        // 3. 다시 가릴 때
        input.type = 'password';
        icon.textContent = 'visibility';
        
        // 💡 다시 가릴 때 별표(마스킹)로 되돌리고 싶다면 아래 주석 해제
        // if (input.value !== '') input.value = '********************';
    }
};

window.showApiKeyModal = function() {
    const modal = document.getElementById('api-key-modal');
    if (!modal) injectApiKeyModal();
    loadKeysIntoUI(); 
    document.getElementById('api-key-modal').style.display = 'block';
    document.body.style.overflow = 'hidden';
};

/* --- 1. saveApiKeys 수정 (가장 중요!) --- */
window.saveApiKeys = function() {
    const saved = localStorage.getItem(STORAGE_KEY);
    const currentKeys = saved ? JSON.parse(saved) : {};
    
    const gVal = document.getElementById('gemini-key').value.trim();
    const grVal = document.getElementById('groq-key').value.trim();
    const hfVal = document.getElementById('hf-key').value.trim();

    // 💡 헬퍼: 진짜 키인지 마스킹인지 판별 (별표가 5개 이상 연속되면 마스킹으로 간주)
    const isMasked = (val) => val.includes('**********');

    const keysToSave = {
        gemini: isMasked(gVal) ? (currentKeys.gemini || '') : gVal,
        groq:   isMasked(grVal) ? (currentKeys.groq || '')   : grVal,
        hf:     isMasked(hfVal) ? (currentKeys.hf || '')     : hfVal,
        
        geminiModel: document.getElementById('gemini-model-select')?.value.trim() || 'gemini-2.0-flash',
        groqModel:   document.getElementById('groq-model-select')?.value.trim()   || 'llama-3.3-70b-versatile',
        hfModel:     document.getElementById('hf-model-select')?.value.trim()     || 'Qwen/Qwen2.5-Coder-32B-Instruct'
    };

    localStorage.setItem(STORAGE_KEY, JSON.stringify(keysToSave));
    
    // 💡 저장 후 UI 즉시 갱신 (마스킹 상태로 돌림)
    loadKeysIntoUI();
    
    alert('Settings saved successfully! 🔐');
    closeApiKeyModal();
};



window.deleteApiKeys = function() {
    if (confirm('⚠️ All API keys and configurations will be permanently deleted. Proceed?')) {
        localStorage.removeItem(STORAGE_KEY);
        
        // [수정] gemini-model → gemini-model-select
        const inputs = ['gemini-key', 'groq-key', 'hf-key', 'gemini-model-select', 'groq-model-select', 'hf-model-select'];
        inputs.forEach(id => {
            const el = document.getElementById(id);
            if (el) {
                if (id.includes('model')) {
                    // 모델 select의 기본값 설정
                    if (id.includes('gemini')) el.value = 'gemini-2.0-flash';
                    else if (id.includes('groq')) el.value = 'llama-3.3-70b-versatile';
                    else if (id.includes('hf')) el.value = 'Qwen/Qwen2.5-Coder-32B-Instruct';
                } else {
                    el.value = '';
                }
            }
        });

        alert('All settings have been cleared. 🧹');
        closeApiKeyModal();
    }
};

window.closeApiKeyModal = function() {
    const modal = document.getElementById('api-key-modal');
    if (modal) {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
};

/* -----------------------------------------------------------
   C. Initialization
   ----------------------------------------------------------- */

document.addEventListener('DOMContentLoaded', () => {
    const sidebarToggle = document.getElementById('sidebarToggle');
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', () => {
            document.body.classList.toggle('sidebar-closed');
            localStorage.setItem('kivosy_sidebar_state', document.body.classList.contains('sidebar-closed') ? 'closed' : 'open');
        });
    }
    injectApiKeyModal();
});

window.addEventListener('click', (e) => {
    if (e.target.id === 'api-key-modal') closeApiKeyModal();
});