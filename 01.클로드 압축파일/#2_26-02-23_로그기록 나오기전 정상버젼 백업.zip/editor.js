/**
 * 에디터 모드 실행
 */
function handleEditMode() {
  // 1. core.js에서 넣어준 전역 변수를 최우선 확인
  let code = window.lastGeneratedCode;
  
  // 2. 만약 없다면 Storage 엔진의 세션 상태(Getter)에서 직접 가져오기
  if (!code && window.KivosyStorage && window.KivosyStorage.session) {
    // 💡 .getActiveApp() 대신 .activeApp (Getter 방식) 사용
    const activeData = window.KivosyStorage.session.activeApp;
    code = activeData ? activeData.html : null;
  }

  if (!code) {
    alert("수정할 코드를 불러오지 못했습니다. 앱을 생성한 후 다시 시도해 주세요.");
    return;
  }

  const overlay = document.getElementById('editor-overlay');
  const textarea = document.getElementById('main-editor');
  
  textarea.value = code;
  overlay.style.display = 'flex';
  
  // 에디터를 열자마자 미리보기도 동기화
  applyAndPreview();
}

/**
 * 수정한 코드를 미리보기에 반영하고 전역 변수 업데이트
 */
function applyAndPreview() {
  const editedCode = document.getElementById('main-editor').value;
  const previewFrame = document.getElementById('editor-preview');
  const status = document.getElementById('editor-status');
  
  // iframe에 코드 주입
  const blob = new Blob([editedCode], { type: 'text/html' });
  const url = URL.createObjectURL(blob);
  previewFrame.src = url;
  
  // 전역 코드 변수 업데이트 (Open이나 Copy 시 이 코드가 사용되도록)
  lastGeneratedCode = editedCode; 
  
  // 기존 메인화면의 Preview도 동시에 업데이트
  const mainPreview = document.getElementById('result-preview');
  if (mainPreview) mainPreview.src = url;

  status.innerText = "Changes Applied!";
  status.style.color = "#4ade80";
  setTimeout(() => {
    status.innerText = "Editing...";
    status.style.color = "#94a3b8";
  }, 2000);
}

/**
 * 에디터 닫기
 */
function closeEditor() {
  document.getElementById('editor-overlay').style.display = 'none';
}