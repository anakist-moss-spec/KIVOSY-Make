// ============================================================
// KIVOSY Factory Next Gen — storage.js
// Data & State Layer  |  v1.0.0
//
// Architecture: Three responsibilities, zero global pollution.
//
//   AppRepository   — CRUD for generated HTML apps + metadata
//   UsageRepository — Daily rate-limit tracking & persistence
//   SessionState    — In-memory, ephemeral per-tab context
//
// Adapter contract: AppRepository and UsageRepository expose
// only async methods, making a future swap to Supabase / D1
// a drop-in replacement with zero callers needing changes.
// ============================================================

'use strict';

// ─────────────────────────────────────────────────────────────
// § 1. AppMetadata Schema  (typed via JSDoc for IDE support)
// ─────────────────────────────────────────────────────────────
/**
 * @typedef {Object} AppMetadata
 * @property {string}   uuid        - RFC-4122 v4 UUID, primary key
 * @property {string}   prompt      - Original user prompt (trimmed to 200 chars)
 * @property {string}   createdAt   - ISO-8601 creation timestamp
 * @property {string}   updatedAt   - ISO-8601 last-modified timestamp
 * @property {number}   sizeKB      - Stored HTML size in kilobytes (2 d.p.)
 * @property {boolean}  isFavorite  - User-starred flag
 * @property {string}   modelUsed   - LLM model that generated this app
 * @property {string[]} tags        - User-defined or auto-detected tag list
 * @property {number}   revision    - Edit counter (starts at 1 on creation)
 */

/**
 * @typedef {Object} SaveResult
 * @property {AppMetadata} meta  - Persisted metadata record
 * @property {boolean}     isNew - true on first save, false on update
 */


// ─────────────────────────────────────────────────────────────
// § 2. Internal Helpers
// ─────────────────────────────────────────────────────────────

/** Returns today's date as "YYYY-MM-DD" in local time. */
function _todayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

/** Calculates a Blob's size in KB, rounded to 2 decimal places. */
function _sizeKB(str) {
  return parseFloat((new Blob([str]).size / 1024).toFixed(2));
}

/**
 * Generates a RFC-4122 v4 UUID without external dependencies.
 * Prefers crypto.randomUUID() when available (modern browsers / Node ≥ 15).
 * @returns {string}
 */
function _generateUUID() {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  // Fallback: manual bit-fiddling
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    return (c === 'x' ? r : (r & 0x3) | 0x8).toString(16);
  });
}

/**
 * Safe localStorage wrapper — never throws.
 * Returns null on any error (private browsing, storage quota exceeded, etc.)
 */
const _ls = {
  get(key) {
    try { return localStorage.getItem(key); }
    catch { return null; }
  },
  set(key, value) {
    try { localStorage.setItem(key, value); return true; }
    catch (e) {
      console.error(`[KIVOSY Storage] localStorage.setItem("${key}") failed:`, e);
      return false;
    }
  },
  remove(key) {
    try { localStorage.removeItem(key); return true; }
    catch { return false; }
  },
  parseJSON(key, fallback) {
    const raw = _ls.get(key);
    if (!raw) return fallback;
    try { return JSON.parse(raw); }
    catch { return fallback; }
  },
};


// ─────────────────────────────────────────────────────────────
// § 3. AppRepository
//      Responsible for persisting generated app HTML and its
//      associated metadata. Designed as an async interface so
//      callers need no changes when the storage backend is
//      replaced with Supabase, Cloudflare D1, or IndexedDB.
// ─────────────────────────────────────────────────────────────
class AppRepository {
  // Storage key constants — centralised so a rename is one-line
  static #KEYS = {
    HTML_PREFIX:  'kivosy_app_html_',  // + uuid → raw HTML string
    META_PREFIX:  'kivosy_app_meta_',  // + uuid → JSON AppMetadata
    INDEX:        'kivosy_app_index',  // JSON array of AppMetadata (newest-first)
  };

  /** Maximum number of apps persisted in the index. Oldest are evicted. */
  static #MAX_INDEX_SIZE = 50;

  // ── Read ──────────────────────────────────────────────────

  /**
   * Retrieves the raw HTML for one app.
   * @param {string} uuid
   * @returns {Promise<string|null>}
   */
  async getHtml(uuid) {
    return _ls.get(AppRepository.#KEYS.HTML_PREFIX + uuid);
  }

  /**
   * Retrieves the metadata record for one app.
   * @param {string} uuid
   * @returns {Promise<AppMetadata|null>}
   */
  async getMeta(uuid) {
    return _ls.parseJSON(AppRepository.#KEYS.META_PREFIX + uuid, null);
  }

  /**
   * Returns the full index of app metadata, newest-first.
   * @returns {Promise<AppMetadata[]>}
   */
  async getIndex() {
    return _ls.parseJSON(AppRepository.#KEYS.INDEX, []);
  }

  /**
   * Returns only the apps marked as favourite.
   * @returns {Promise<AppMetadata[]>}
   */
  async getFavorites() {
    const index = await this.getIndex();
    return index.filter(m => m.isFavorite === true);
  }

  /**
   * Case-insensitive full-text search across prompt text.
   * @param {string} query
   * @returns {Promise<AppMetadata[]>}
   */
  async search(query) {
    if (!query || typeof query !== 'string') return this.getIndex();
    const q = query.toLowerCase().trim();
    const index = await this.getIndex();
    return index.filter(m => m.prompt.toLowerCase().includes(q));
  }

  // ── Write ─────────────────────────────────────────────────

  /**
   * Saves a newly generated app (HTML + metadata) to storage.
   *
   * On first save:   creates a fresh AppMetadata record.
   * On re-save:      updates html, sizeKB, updatedAt, revision.
   *
   * @param {string} htmlCode      - Complete generated HTML string
   * @param {string} userPrompt    - Original user prompt
   * @param {Object} [options]     - Optional creation hints
   * @param {string} [options.modelUsed]  - e.g. "gemini-2.5-flash"
   * @param {string[]} [options.tags]     - Initial tag list
   * @param {string} [options.uuid]       - Supply to force a specific UUID (update path)
   * @returns {Promise<SaveResult>}
   */
  async save(htmlCode, userPrompt, options = {}) {
    const now = new Date().toISOString();
    const isNew = !options.uuid;
    const uuid  = options.uuid ?? _generateUUID();

    // Retrieve existing meta (update path) or build fresh record
    const existing = isNew ? null : await this.getMeta(uuid);

    /** @type {AppMetadata} */
    const meta = {
      uuid,
      prompt:     (userPrompt ?? '').trim().slice(0, 200),
      createdAt:  existing?.createdAt ?? now,
      updatedAt:  now,
      sizeKB:     _sizeKB(htmlCode),
      isFavorite: existing?.isFavorite ?? false,
      modelUsed:  options.modelUsed ?? existing?.modelUsed ?? 'unknown',
      tags:       options.tags      ?? existing?.tags      ?? [],
      revision:   (existing?.revision ?? 0) + 1,
    };

    // ① Persist raw HTML
    const htmlKey = AppRepository.#KEYS.HTML_PREFIX + uuid;
    if (!_ls.set(htmlKey, htmlCode)) {
      throw new Error('[AppRepository.save] localStorage quota exceeded while saving HTML.');
    }

    // ② Persist metadata object
    const metaKey = AppRepository.#KEYS.META_PREFIX + uuid;
    _ls.set(metaKey, JSON.stringify(meta));

    // ③ Update master index (evict oldest if over limit)
    const index = await this.getIndex();

    if (isNew) {
      index.unshift(meta);                                    // newest first
      if (index.length > AppRepository.#MAX_INDEX_SIZE) {
        // Remove the evicted entry's HTML and meta from storage too
        const evicted = index.pop();
        _ls.remove(AppRepository.#KEYS.HTML_PREFIX + evicted.uuid);
        _ls.remove(AppRepository.#KEYS.META_PREFIX + evicted.uuid);
      }
    } else {
      // Replace the existing index entry in-place
      const idx = index.findIndex(m => m.uuid === uuid);
      if (idx !== -1) index[idx] = meta;
      else index.unshift(meta);                               // failsafe
    }

    _ls.set(AppRepository.#KEYS.INDEX, JSON.stringify(index));

    return { meta, isNew };
  }

  /**
   * Toggles the isFavorite flag for an app.
   * @param {string} uuid
   * @returns {Promise<boolean>} The new isFavorite value, or false if not found.
   */
  async toggleFavorite(uuid) {
    const meta = await this.getMeta(uuid);
    if (!meta) return false;

    meta.isFavorite = !meta.isFavorite;
    meta.updatedAt  = new Date().toISOString();
    _ls.set(AppRepository.#KEYS.META_PREFIX + uuid, JSON.stringify(meta));

    // Sync into index
    const index = await this.getIndex();
    const i = index.findIndex(m => m.uuid === uuid);
    if (i !== -1) {
      index[i].isFavorite = meta.isFavorite;
      _ls.set(AppRepository.#KEYS.INDEX, JSON.stringify(index));
    }

    return meta.isFavorite;
  }

  /**
   * Adds or removes a tag from an app's metadata.
   * @param {string}   uuid
   * @param {string}   tag
   * @param {'add'|'remove'} action
   * @returns {Promise<string[]>} Updated tag array, or [] if not found.
   */
  async updateTags(uuid, tag, action = 'add') {
    const meta = await this.getMeta(uuid);
    if (!meta) return [];

    const tags = meta.tags ?? [];
    if (action === 'add' && !tags.includes(tag)) {
      tags.push(tag);
    } else if (action === 'remove') {
      const pos = tags.indexOf(tag);
      if (pos !== -1) tags.splice(pos, 1);
    }

    meta.tags      = tags;
    meta.updatedAt = new Date().toISOString();
    _ls.set(AppRepository.#KEYS.META_PREFIX + uuid, JSON.stringify(meta));

    // Sync into index
    const index = await this.getIndex();
    const i = index.findIndex(m => m.uuid === uuid);
    if (i !== -1) {
      index[i].tags = tags;
      _ls.set(AppRepository.#KEYS.INDEX, JSON.stringify(index));
    }

    return tags;
  }

  // ── Delete ────────────────────────────────────────────────

  /**
   * Permanently removes one app and its metadata from storage.
   * @param {string} uuid
   * @returns {Promise<boolean>} true if something was actually deleted
   */
  async delete(uuid) {
    const htmlKey = AppRepository.#KEYS.HTML_PREFIX + uuid;
    const metaKey = AppRepository.#KEYS.META_PREFIX + uuid;

    const existed = _ls.get(metaKey) !== null;
    _ls.remove(htmlKey);
    _ls.remove(metaKey);

    const index = (await this.getIndex()).filter(m => m.uuid !== uuid);
    _ls.set(AppRepository.#KEYS.INDEX, JSON.stringify(index));

    return existed;
  }

  /**
   * Wipes ALL app data managed by this repository.
   * Used for "reset" / testing scenarios. Prompt before calling!
   * @returns {Promise<number>} Count of entries removed.
   */
  async deleteAll() {
    const index = await this.getIndex();
    for (const meta of index) {
      _ls.remove(AppRepository.#KEYS.HTML_PREFIX + meta.uuid);
      _ls.remove(AppRepository.#KEYS.META_PREFIX + meta.uuid);
    }
    _ls.remove(AppRepository.#KEYS.INDEX);
    return index.length;
  }

  // ── Storage Diagnostics ───────────────────────────────────

  /**
   * Returns a lightweight storage health snapshot.
   * Useful for admin panels or debugging overlays.
   * @returns {Promise<Object>}
   */
  async diagnostics() {
    const index = await this.getIndex();
    let totalKB = 0;
    for (const m of index) totalKB += m.sizeKB;
    return {
      appCount:       index.length,
      totalStorageKB: parseFloat(totalKB.toFixed(2)),
      favoriteCount:  index.filter(m => m.isFavorite).length,
      oldestApp:      index.at(-1)?.createdAt ?? null,
      newestApp:      index.at(0)?.createdAt  ?? null,
    };
  }
}


// ─────────────────────────────────────────────────────────────
// § 4. UsageRepository (수정본)
// ─────────────────────────────────────────────────────────────
class UsageRepository {
  // 🎯 무제한이므로 판단할 필요 없이 무조건 OK!
  async canGenerate() {
    return true; 
  }

  // 통계 기록은 나중에 공장장님이 "내가 얼마나 썼지?" 궁금할 때 보실 수 있게 유지합니다.
  async recordCall(modelName) {
    const today = new Date().toISOString().slice(0, 10);
    const key = `kivosy_usage_${today}`;
    let stats = JSON.parse(localStorage.getItem(key) || '{}');
    stats[modelName] = (stats[modelName] || 0) + 1;
    localStorage.setItem(key, JSON.stringify(stats));
  }

  async getDailyStats() {
    const today = new Date().toISOString().slice(0, 10);
    const key = `kivosy_usage_${today}`;
    return JSON.parse(localStorage.getItem(key) || '{}');
  }

  // 에러 방지용 가짜 함수들
  async increment() { return; }
  async getSummary() { return { used: 0, max: Infinity }; }
}

// ─────────────────────────────────────────────────────────────
// § 5. SessionState
//      Pure in-memory, per-tab context manager.
//      Nothing here is persisted — it resets on page reload,
//      which is the correct contract for ephemeral UI state.
//
//      Consumers subscribe to change events rather than
//      polling properties, keeping the UI reactive without
//      a framework dependency.
// ─────────────────────────────────────────────────────────────
class SessionState {
  /**
   * @typedef {Object} ActiveApp
   * @property {string}   uuid      - Currently focused app UUID
   * @property {string}   html      - In-memory HTML (may differ from storage if unsaved)
   * @property {boolean}  isDirty   - true if html has unsaved changes
   * @property {string[]} chatHistory - Modification requests sent this session
   */

  #state = {
    /** @type {ActiveApp|null} */
    activeApp:        null,

    /** Generation in progress flag (disable UI while true) */
    isGenerating:     false,

    /** Chat modification in progress */
    isModifying:      false,

    /** Most recent error message to surface in the UI */
    lastError:        null,

    /** Most recent progress message from the generation pipeline */
    lastProgressMsg:  null,

    /** Selected LLM provider preference */
    preferredModel:   'gemini',
  };

  /** @type {Map<string, Set<Function>>} */
  #listeners = new Map();

  // ── Getters (read-only snapshots) ─────────────────────────

  get activeApp()       { return this.#state.activeApp;       }
  get isGenerating()    { return this.#state.isGenerating;    }
  get isModifying()     { return this.#state.isModifying;     }
  get lastError()       { return this.#state.lastError;       }
  get lastProgressMsg() { return this.#state.lastProgressMsg; }
  get preferredModel()  { return this.#state.preferredModel;  }

  // ── Setters (each fires an event so UI can react) ─────────

  /** @param {ActiveApp} app */
  setActiveApp(app) {
    this.#state.activeApp = app;
    this.#emit('activeApp', app);
  }

  clearActiveApp() {
    this.#state.activeApp = null;
    this.#emit('activeApp', null);
  }

  /** @param {boolean} flag */
  setGenerating(flag) {
    this.#state.isGenerating = Boolean(flag);
    this.#emit('isGenerating', this.#state.isGenerating);
    if (flag) this.clearError();
  }

  /** @param {boolean} flag */
  setModifying(flag) {
    this.#state.isModifying = Boolean(flag);
    this.#emit('isModifying', this.#state.isModifying);
  }

  /** @param {string|null} msg */
  setError(msg) {
    this.#state.lastError = msg;
    this.#emit('lastError', msg);
  }

  clearError() {
    this.setError(null);
  }

  /** @param {string} msg */
  setProgressMsg(msg) {
    this.#state.lastProgressMsg = msg;
    this.#emit('lastProgressMsg', msg);
  }

  /** @param {'gemini'|'groq'} model */
  setPreferredModel(model) {
    this.#state.preferredModel = model;
    this.#emit('preferredModel', model);
  }

  /**
   * Patches the active app's HTML in-memory and marks it dirty.
   * Does NOT write to localStorage — call AppRepository.save() for that.
   * @param {string} newHtml
   */
  patchActiveHtml(newHtml) {
    if (!this.#state.activeApp) return;
    this.#state.activeApp.html    = newHtml;
    this.#state.activeApp.isDirty = true;
    this.#emit('activeApp', this.#state.activeApp);
  }

  /**
   * Appends a message to the active app's chat history.
   * @param {string} message
   */
  appendChatMessage(message) {
    if (!this.#state.activeApp) return;
    this.#state.activeApp.chatHistory = this.#state.activeApp.chatHistory ?? [];
    this.#state.activeApp.chatHistory.push(message);
    // No event emitted — chat rendering is handled separately
  }

  // ── Event Bus ─────────────────────────────────────────────

  /**
   * Subscribes to a state field change.
   * @param {string}   field    - One of the state keys
   * @param {Function} handler  - Called with the new value
   * @returns {Function} Unsubscribe function
   */
  on(field, handler) {
    if (!this.#listeners.has(field)) this.#listeners.set(field, new Set());
    this.#listeners.get(field).add(handler);
    // Return an unsubscribe function for clean teardown
    return () => this.#listeners.get(field)?.delete(handler);
  }

  /**
   * @param {string} field
   * @param {*}      value
   */
  #emit(field, value) {
    this.#listeners.get(field)?.forEach(fn => {
      try { fn(value); }
      catch (e) { console.error(`[SessionState] handler for "${field}" threw:`, e); }
    });
  }

  /**
   * Returns a read-only plain-object snapshot of the current state.
   * Safe to log or pass to debugging tools.
   * @returns {Object}
   */
  snapshot() {
    return JSON.parse(JSON.stringify(this.#state));
  }
}


// ─────────────────────────────────────────────────────────────
// § 6. StorageEngine
//      Single façade that wires the three repositories together
//      and exposes them as a unified singleton.
//      This is the only symbol placed on `window`.
// ─────────────────────────────────────────────────────────────
class StorageEngine {
  /**
   * @param {Object} [config]
   * @param {number} [config.maxAppsPerDay=10]
   */
  constructor(config = {}) {
    /** @type {AppRepository} */
    this.apps    = new AppRepository();

    /** @type {UsageRepository} */
    this.usage   = new UsageRepository({ maxPerDay: config.maxAppsPerDay ?? 10 });

    /** @type {SessionState} */
    this.session = new SessionState();

    Object.freeze(this); // prevent accidental property mutation
  }

  /**
   * Convenience: checks generation eligibility and increments counter
   * in one atomic-feeling call. Used by the core engine before calling
   * any LLM API.
   *
   * @throws {Error} If the daily limit has been reached.
   * @returns {Promise<void>}
   */
  async assertAndConsumeQuota() {
    const allowed = await this.usage.canGenerate();
    if (!allowed) {
      const summary = await this.usage.getSummary();
      throw new Error(
          "🌐 System Optimization: We are currently tuning our servers for better performance. " +
          "Please wait a moment and try again shortly."
      );
    }
    await this.usage.increment();
  }
}


// ─────────────────────────────────────────────────────────────
// § 7. Bootstrap
//      Expose a single, frozen singleton on window.
//      All other modules import from this object.
// ─────────────────────────────────────────────────────────────

// 🎯 maxAppsPerDay를 아주 크게 잡거나, 위에서 true를 뱉으므로 사실상 무제한!
/**
 * 전역 객체 생성 및 별명 부여
 * @type {StorageEngine}
 * @global
 */
// 🎯 maxAppsPerDay는 이제 의미 없지만, 형식을 위해 큰 값을 넣어둡니다.
const kivosyInstance = new StorageEngine({ maxAppsPerDay: 999999 });

// 다른 코드들이 KivosyStorage로 부르든 Storage로 부르든 모두 응답하게 합니다.
window.KivosyStorage = kivosyInstance;
window.Storage       = kivosyInstance; 

// 불필요한 수정을 막기 위해 얼려버립니다.
Object.freeze(window.KivosyStorage);

console.log("🚀 [KIVOSY Engine] Unlimited Mode Activated. Systems nominal.");
