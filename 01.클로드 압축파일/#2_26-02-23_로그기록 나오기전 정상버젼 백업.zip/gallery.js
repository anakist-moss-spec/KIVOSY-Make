/* ============================================================
   SECTION: Gallery Page Logic (gallery.js) - Global Final
   ============================================================ */

document.addEventListener('DOMContentLoaded', () => {
  const checkReady = setInterval(() => {
    if (window.UIEngine && window.KivosyStorage) {
      clearInterval(checkReady);
      loadGalleryPage();
    }
  }, 80);

  async function loadGalleryPage() {
    try {
      const allApps = await window.KivosyStorage.getIndex();
      updateStats(allApps);
      window._galleryApps = allApps;
      renderGalleryCards(allApps);

      // 🎯 [추가] 상단 배지 숫자를 새로고침합니다!
      if (window.QuotaDisplay && window.QuotaDisplay.refresh) {
          await window.QuotaDisplay.refresh();
      }

    } catch (err) {
      console.error('[Gallery] Load failed:', err);
    }
  }

  // ... 나머지 함수들은 그대로 두시면 됩니다 ...

  function updateStats(apps) {
    const countEl = document.getElementById('app-count');
    if (countEl) countEl.textContent = apps.length;
  }

  window.filterGallery = () => {
    const query = document.getElementById('search-input')?.value.toLowerCase().trim() || '';
    const all = window._galleryApps || [];
    const filtered = query
      ? all.filter(a => a.prompt.toLowerCase().includes(query))
      : all;
    renderGalleryCards(filtered);
  };

  if (window.UIEngine) {
    const origDelete = window.UIEngine.deleteApp.bind(window.UIEngine);
    window.UIEngine.deleteApp = async (uuid) => {
      // 🎯 삭제 확인창 영문으로 변경
      if(confirm('Are you sure you want to delete this app? This action cannot be undone.')) {
        await origDelete(uuid);
        await loadGalleryPage();
      }
    };
  }
});

function renderGalleryCards(apps) {
  const grid = document.getElementById('gallery-grid');
  if (!grid) return;

  if (apps.length === 0) {
    // 🎯 빈 상태 메시지 영문으로 단일화
    grid.innerHTML = `
      <div style="grid-column: 1/-1; text-align: center; padding: 60px; color: var(--text-tertiary);">
        <div style="font-size: 48px; margin-bottom: 16px;">📂</div>
        <p style="font-size: 18px; font-weight: 500;">No apps found.</p>
        <p style="font-size: 14px; margin-top: 8px;">Let's create your first AI app in the Studio!</p>
      </div>`;
    return;
  }

  grid.innerHTML = apps.map(app => `
    <div class="g-card">
      <div class="g-card-preview" style="background: var(--indigo-soft); height: 160px; display: flex; align-items: center; justify-content: center; font-size: 40px;">
        ${app.icon || '🚀'}
      </div>
      <div class="g-card-content" style="padding: 20px;">
        <div class="g-card-prompt" style="font-weight: 600; margin-bottom: 12px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; height: 40px; color: var(--text-primary);">
          ${app.prompt}
        </div>
        <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 12px;">
          <span style="font-size: 12px; color: var(--text-tertiary);">${app.createdAt.slice(0, 10)}</span>
          <div style="display: flex; gap: 8px;">
            <button onclick="window.UIEngine.deleteApp('${app.uuid}')" style="padding: 6px; background: none; border: none; cursor: pointer; color: var(--rose); font-size: 14px;" title="Delete">🗑️</button>
            <button onclick="location.href='index.html?id=${app.uuid}'" style="padding: 6px 16px; border-radius: 99px; border: 1px solid var(--border); background: white; cursor: pointer; font-size: 13px; font-weight: 500; transition: all 0.2s;" onmouseover="this.style.borderColor='var(--indigo)';this.style.color='var(--indigo)';" onmouseout="this.style.borderColor='var(--border)';this.style.color='inherit';">Edit</button>
          </div>
        </div>
      </div>
    </div>
  `).join('');
}