# 🏭 KIVOSY App Factory — 공장장님 구현 가이드

> Chief Claude Officer 작성  
> DeepSeek Officer Vision: "Conversation-to-App Factory" MVP  
> KIVOSY Security Core v4.2.0 내장

---

## 📁 전달 파일 목록

| 파일 | 역할 |
|------|------|
| `app-factory.js` | 핵심 로직 — API 호출, 보안 검증, 저장소 |
| `app-factory-tab.html` | UI 스니펫 — 탭 버튼, 패널, 스타일, 컨트롤러 |
| `IMPLEMENTATION_GUIDE.md` | 이 파일 |

---

## 🚀 Step 1: 파일 배치

```
lab.kivosy.com/
├── index.html          ← 기존 파일 (수정 필요)
├── app.js              ← 기존 파일 (수정 불필요)
├── style.css           ← 기존 파일 (선택적 수정)
├── app-factory.js      ← ✅ 새 파일 추가
└── app-factory-tab.html ← 참고용 (코드를 index.html에 병합)
```

---

## 🔧 Step 2: index.html 수정 — 4곳만 바꾸면 됩니다

### 2-1. `<head>` 안에 app-factory.js 로드 추가

```html
<!-- 기존 스크립트들 다음에 추가 -->
<script src="app-factory.js"></script>
```

### 2-2. 탭 버튼 목록에 App Factory 버튼 추가

기존 탭 버튼들 (All Models, Gemini, Groq, HF) 뒤에 삽입:

```html
<button class="tab-btn factory-tab-btn" data-tab="app-factory" id="tab-app-factory">
  🏭 App Factory
  <span class="factory-badge" id="factory-remaining-badge">10</span>
</button>
```

### 2-3. 탭 패널 영역에 App Factory 패널 추가

`app-factory-tab.html`의 `<!-- ② 탭 컨텐츠 영역 -->` 블록 전체를  
기존 탭 패널들과 같은 레벨에 삽입합니다.

### 2-4. `<head>` 또는 `<style>` 에 CSS 추가

`app-factory-tab.html`의 `<!-- ③ 스타일 -->` 블록을 기존 CSS 파일에 추가하거나  
`index.html`의 `</head>` 바로 앞에 붙여넣기

### 2-5. `</body>` 앞에 스크립트 추가

`app-factory-tab.html`의 `<!-- ④ 스크립트 -->` 블록을 `</body>` 바로 앞에 삽입

---

## 🔑 Step 3: API 키 연동 확인

`handleFactoryGenerate()` 함수 안의 localStorage 키 이름을  
기존 KIVOSY Lab에서 사용하는 실제 키 이름으로 맞춰주세요:

```javascript
// app-factory-tab.html 내 handleFactoryGenerate() 수정
const apiKeys = {
  gemini: localStorage.getItem('여기에_실제_Gemini_키_이름'),
  groq:   localStorage.getItem('여기에_실제_Groq_키_이름'),
};
```

현재 기본값: `'kivosy_gemini_key'`, `'geminiApiKey'`, `'groqApiKey'`  
(둘 다 시도하므로 기존 키 이름이 이 중 하나라면 수정 불필요)

---

## 💰 Step 4: AdSense 설정 (수익화)

`app-factory.js` 내 `buildAdSenseSlot()` 함수에서:

```javascript
// 실제 AdSense 값으로 교체
data-ad-client="ca-pub-XXXXXXXXXXXXXXXXX"   ← 실제 Publisher ID
data-ad-slot="XXXXXXXXXX"                   ← 실제 Ad Slot ID
```

그리고 `buildKivosyElements()` 함수의 adSenseScript도 동일하게 수정:
```javascript
?client=ca-pub-XXXXXXXXXXXXXXXXX   ← 동일한 Publisher ID
```

---

## 🔒 Step 5: 기존 탭 시스템과 연결

기존 탭 전환 로직(app.js)이 패널 show/hide를 어떻게 처리하는지 확인 후,  
`data-tab="app-factory"` → `id="panel-app-factory"` 가 제대로 연결되는지 확인하세요.

예) 기존 탭 시스템이 `panel-${data-tab}` 패턴을 사용한다면 자동 연결됩니다.

---

## 🧪 Step 6: 테스트 체크리스트

- [ ] App Factory 탭 버튼이 보이는가
- [ ] 탭 클릭 시 패널이 열리는가
- [ ] API 키 미설정 시 경고 메시지가 뜨는가
- [ ] 프롬프트 입력 후 생성 버튼 클릭 → 진행 상태 표시되는가
- [ ] 코드 생성 후 iframe 미리보기가 표시되는가
- [ ] "앱 열기" 클릭 시 새 탭에서 앱이 열리는가
- [ ] 생성된 앱에 "Made with KIVOSY Labs" 푸터가 있는가
- [ ] 10개 생성 후 사용 한도 초과 메시지가 뜨는가
- [ ] 보안 위반 코드 생성 시 오류 메시지가 뜨는가

---

## 🏗️ 아키텍처 요약

```
사용자 입력
    ↓
프롬프트 인젝션 검사 (Security Core)
    ↓
일일 사용량 확인 (RateLimiter, max 10/day)
    ↓
멀티모델 앙상블 (Gemini → Groq 순서로 폴백)
    ↓
생성된 코드 보안 검증 (위험 패턴 15종 스캔)
    ↓
KIVOSY 요소 주입 (AdSense + 푸터)
    ↓
localStorage 저장 (UUID 키)
    ↓
iframe 미리보기 표시
    ↓
"앱 열기" → Blob URL → 새 탭
```

---

## ⚠️ 알려진 제약사항

1. **localStorage 용량**: 브라우저당 ~5-10MB 제한. 앱 50개 초과 시 자동으로 오래된 항목 삭제됨.
2. **iframe sandbox**: 생성된 앱의 일부 기능(알림 등)이 sandbox로 인해 미리보기에서 제한될 수 있음. 실제 열기에서는 정상 작동.
3. **오프라인**: CDN 의존 앱은 최초 1회 온라인 접속 필요.
4. **Blob URL 수명**: 탭/창을 닫으면 만료됨. 영구 공유는 localStorage에서 재생성.

---

## 🔮 추후 업그레이드 제안 (v2.0)

- [ ] HuggingFace API 코드 생성 모델 추가 (3번째 앙상블)
- [ ] 앱 공유 기능 (URL 파라미터로 Base64 인코딩)
- [ ] 생성된 앱 카테고리 태깅
- [ ] 앱 버전 관리 (수정/재생성)
- [ ] 코드 에디터 내장 (수동 수정 가능)

---

*Made with ❤️ by Chief Claude Officer @ KIVOSY Factory*
